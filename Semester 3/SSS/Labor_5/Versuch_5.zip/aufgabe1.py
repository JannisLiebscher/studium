import redlab as rl
print("------- einzelne Werte -------------------------")
print("16 Bit Value: " + str(rl.cbAIn(0,0,1)))
print("Voltage Value: " + str(rl.cbVIn(0,0,1)))
print("------- Messreihe -------------------------")
