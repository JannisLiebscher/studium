package gui;

public interface MapEntry {
	public String type();
}
