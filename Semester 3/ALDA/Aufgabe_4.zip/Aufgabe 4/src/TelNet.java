import java.util.*;

public class TelNet {
    private final int lbg;
    private PriorityQueue<TelVerbindung> edges;
    private UnionFind forest;
    private List<TelVerbindung> minSpanTree;
    private Map<TelKnoten, Integer> knotenMap;

    public TelNet(int lbg) {
        this.lbg = lbg;
        knotenMap = new HashMap<>();
    }

    /**
     * Fügt einen neuen Telefonknoten mit Koordinate (x,y) dazu.
     *
     * @param x
     * @param y
     * @return true, falls die Koordinate neu ist, sonst false.
     */
    public boolean addTelKnoten(int x, int y) {
        TelKnoten t = new TelKnoten(x, y);
        if (knotenMap.containsValue(t))
            return false;
        knotenMap.put(t, knotenMap.size());
        return true;
    }

    /**
     * Liefert ein optimales Telefonnetz als Liste von Telefonverbindungen zurück.
     */
    public boolean computeOptTelNet() {
        forest = new UnionFind(knotenMap.size());
        edges = new PriorityQueue<>(knotenMap.size(), Comparator.comparing(comp -> comp.c)); //priority depends on cost
        minSpanTree = new LinkedList<>();
        generateEdges();

        while (forest.size != 1 && !edges.isEmpty()) {
            TelVerbindung t = edges.poll();

            //tree representatives
            int t1 = forest.find(knotenMap.get(t.u));
            int t2 = forest.find(knotenMap.get(t.v));

            if (t1 != t2) {
                forest.union(t1, t2);
                minSpanTree.add(t);
            }
        }
        if (forest.size != 1) {
            minSpanTree = null; //set to null to know there is no minSpanTree
            return false;
        }

        return true;
    }

    /* double loop over all nodes, to generate edges with the condition cost < lbg*/
    private void generateEdges() {
        for (TelKnoten u : knotenMap.keySet())
            for (TelKnoten v : knotenMap.keySet()) {
                if (u.equals(v))
                    continue;
                int cost = manhattanDistance(u, v);
                if (cost <= lbg)
                    edges.add(new TelVerbindung(u, v, cost));
            }

    }

    /* calculates manhattan distance of two nodes */
    private int manhattanDistance(TelKnoten u, TelKnoten v) {
        return Math.abs(u.x - v.x) + Math.abs(u.y - v.y);
    }

    public List<TelVerbindung> getOptTelNet() throws IllegalStateException {
        if (forest == null)
            throw new IllegalStateException("computeOptTelNet has not been called");
        if (minSpanTree == null)
            throw new IllegalStateException("computeOptTelNet was not successful");

        return minSpanTree;
    }

    public int getOptTelNetKosten() throws IllegalStateException {
        if (forest == null)
            throw new IllegalStateException("computeOptTelNet has not been called");
        if (minSpanTree == null)
            throw new IllegalStateException("computeOptTelNet was not successful");
        int cost = 0;
        for (TelVerbindung t : minSpanTree)
            cost += t.c;
        return cost;
    }

    public void drawOptTelNet(int xMax, int yMax) throws IllegalStateException {
        StdDraw.setCanvasSize(1300, 1300);
        StdDraw.setXscale(0, xMax + 1);
        StdDraw.setYscale(0, yMax + 1);
        StdDraw.setPenColor(StdDraw.BLUE);
        for (TelKnoten t : knotenMap.keySet())
            StdDraw.filledSquare(t.x, t.y, 0.5);
        StdDraw.setPenColor(StdDraw.RED);
        for (TelVerbindung t : minSpanTree) {
            StdDraw.line(t.u.x, t.u.y, t.v.x, t.v.y);
            if (xMax < 100)
                StdDraw.text((t.u.x < t.v.x ? t.u.x : t.v.x) + Math.abs(t.u.x - t.v.x) / 2.0 + 0.1, (t.u.y < t.v.y ? t.u.y : t.v.y) + Math.abs(t.u.y - t.v.y) / 2.0 + 0.1, t.c + "");
        }
    }

    public void generateRandomTelNet(int n, int xMax, int yMax) {
        Random random = new Random();
        knotenMap = new HashMap<>();
        for (int i = 0; i < n; i++)
            knotenMap.put(new TelKnoten(random.nextInt(xMax + 1), random.nextInt(yMax + 1)), knotenMap.size());
    }

    public int size() {
        return knotenMap.size();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    public static void drawExample() {
        TelNet telNet = new TelNet(10);
        telNet.addTelKnoten(1, 1);
        telNet.addTelKnoten(3, 1);
        telNet.addTelKnoten(4, 2);
        telNet.addTelKnoten(3, 4);
        telNet.addTelKnoten(2, 6);
        telNet.addTelKnoten(7, 5);
        telNet.addTelKnoten(4, 7);

        telNet.computeOptTelNet();
        System.out.println(telNet.getOptTelNet());
        System.out.println(telNet.getOptTelNetKosten());
        telNet.drawOptTelNet(10, 10);
    }

    public static void drawRandom(int n) {
        TelNet telNet = new TelNet(n);
        telNet.generateRandomTelNet(n, n, n);
        telNet.computeOptTelNet();
        System.out.println(telNet.getOptTelNet());
        System.out.println(telNet.getOptTelNetKosten());
        telNet.drawOptTelNet(n, n);
    }

    public static void main(String[] args) {
        //drawExample();
        drawRandom(1000);
    }
}
