import java.util.Arrays;

public class UnionFind {
    int size;
    int[] p;

    public UnionFind(int n) {
        this.p = new int[n];
        for (int i = 0; i < p.length; i++)
            p[i] = -1;
        size = n;
    }

    public int find(int e) {
        while (p[e] >= 0)
            e = p[e];
        return e;
    }

    /* Union-By-Height */
    public void union(int s1, int s2) {
        if (p[s1] >= 0 || p[s2] >= 0)
            return;
        if (s1 == s2)
            return;
        if (-p[s1] < -p[s2])  // Höhe von s1 < Höhe von s2
            p[s1] = s2;
        else {
            if (-p[s1] == -p[s2])
                p[s1]--; // Höhe von s1 erhöht sich um 1
            p[s2] = s1;
        }
        size--;
    }

    public int size() {
        return size;
    }

    @Override
    public String toString() {
        return "UnionFind{" +
                "size=" + size +
                ", p=" + Arrays.toString(p) +
                '}';
    }

    public static void main(String[] args) {
        UnionFind u = new UnionFind(14);
        u.union(0, 1);
        u.union(0, 2);
        System.out.println(u);

        u.union(7,12);
        System.out.println(u);
        u.union(4,9);
        u.union(4,7);
        System.out.println(u);
        u.union(11,13);
        System.out.println(u);
        u.union(6,10);
        u.union(6,11);
        u.union(6,4);
        System.out.println(u);

        u.union(5,3);
        u.union(5,8);
        System.out.println(u);

        u.union(0,5);
        System.out.println(u);
    }

}
