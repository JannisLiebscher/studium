#!/bin/sh
java -jar JERM.jar 
