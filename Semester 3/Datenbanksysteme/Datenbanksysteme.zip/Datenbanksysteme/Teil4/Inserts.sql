
INSERT INTO Land VALUES ('Deutschland');
INSERT INTO Land VALUES ('Spanien');
INSERT INTO Land VALUES ('Finnland');
INSERT INTO Land VALUES ('Schweden');
INSERT INTO Land VALUES ('Frankreich');

INSERT INTO Adresse VALUES(1,'Tal','64','77770');
INSERT INTO Adresse VALUES(2,'Hauptstra�e','63','72750');
INSERT INTO Adresse VALUES(3,'Baustra�e','23','77240');
INSERT INTO Adresse VALUES(4,'Bergstra�e','66','76270');
INSERT INTO Adresse VALUES(5,'Katzenstra�e','32','72570');
INSERT INTO Adresse VALUES(6,'Stra�estra�e','11','76770');

INSERT INTO Ausstattungen VALUES('Pool', 'Ist halt ein Pool');
INSERT INTO Ausstattungen VALUES('Fernseher', 'Ist halt ein Fernseher');
INSERT INTO Ausstattungen VALUES('K�hlschrank', 'Ist halt ein K�hlschrank');
INSERT INTO Ausstattungen VALUES('So Zeugs halt', 'Ist halt Zeugs halt');
INSERT INTO Ausstattungen VALUES('Toilette', 'Ist halt eine Toilette');
INSERT INTO Ausstattungen VALUES('Bowlingbahn', 'Ist halt eine Bowlingbahn');

INSERT INTO Touristenattraktionen VALUES('Europapark', 'Deutschlands gr��ter Freizeitpark');
INSERT INTO Touristenattraktionen VALUES('Deutschlandpark', 'Kulturpark');
INSERT INTO Touristenattraktionen VALUES('Blumenpark', 'Blumenshow');
INSERT INTO Touristenattraktionen VALUES('Schwimmbad', 'Schwimmbad');
INSERT INTO Touristenattraktionen VALUES('Park', NULL);
INSERT INTO Touristenattraktionen VALUES('Museum', 'Fossilien und so Zeugs');

INSERT INTO Kunde VALUES('peter@web.de','Peter','M�ller','Y','DE02120300000000202051','Petercool','Deutschland',1);
INSERT INTO Kunde VALUES('august@web.de','August','Bauer','N','DE02500105170137075030','Augustus','Spanien',2);  
INSERT INTO Kunde VALUES('tom@web.de','Tom','Walter','Y','DE02100500000054540402','Tomatenkopf','Finnland',3);  
INSERT INTO Kunde VALUES('Anton@web.de','Anton','Eck','Y','DE02300209000106531065','Antonios','Schweden',4);  
INSERT INTO Kunde VALUES('adolf@web.de','Adolf','Spinner','N','DE02200505501015871393','Spinnerwinner','Frankreich',5);  
INSERT INTO Kunde VALUES('Tobias@web.de','Tobias','Latt','N','DE02100100100006820101','Hallo1234','Deutschland',6);

INSERT INTO Ferienwohnung VALUES('Sonnenschein',3,50,450,'Deutschland',1);
INSERT INTO Ferienwohnung VALUES('Mondschein',3,60,500,'Schweden',2);
INSERT INTO Ferienwohnung VALUES('Sternenlicht',4,80,600,'Frankreich',3);
INSERT INTO Ferienwohnung VALUES('Jupiter',5,120,800,'Finnland',4);
INSERT INTO Ferienwohnung VALUES('Mars',5,120,1200,'Spanien',5);
INSERT INTO Ferienwohnung VALUES('Sonnenfels',3,60,400,'Spanien',6);

INSERT INTO Bild VALUES('Bild1.jpg', 'Sonnenschein');
INSERT INTO Bild VALUES('Bild2.jpg', 'Mondschein');
INSERT INTO Bild VALUES('Bild3.jpg', 'Sternenlicht');
INSERT INTO Bild VALUES('Bild4.jpg', 'Jupiter');
INSERT INTO Bild VALUES('Bild5.jpg', 'Mars');
INSERT INTO Bild VALUES('Bild6.jpg', 'Sonnenfels');

INSERT INTO in_der_n�he_von VALUES(9,'Sonnenschein', 'Europapark');
INSERT INTO in_der_n�he_von VALUES(11,'Mondschein', 'Deutschlandpark');
INSERT INTO in_der_n�he_von VALUES(32,'Sternenlicht', 'Blumenpark');
INSERT INTO in_der_n�he_von VALUES(21,'Jupiter', 'Park');
INSERT INTO in_der_n�he_von VALUES(22,'Mars', 'Schwimmbad');
INSERT INTO in_der_n�he_von VALUES(10,'Sonnenfels', 'Museum');

INSERT INTO ist_ausgestattet_mit VALUES('Sonnenschein', 'Pool');
INSERT INTO ist_ausgestattet_mit VALUES('Mondschein', 'Fernseher');
INSERT INTO ist_ausgestattet_mit VALUES('Sternenlicht', 'Toilette');
INSERT INTO ist_ausgestattet_mit VALUES('Jupiter', 'K�hlschrank');
INSERT INTO ist_ausgestattet_mit VALUES('Mars', 'So Zeugs halt');
INSERT INTO ist_ausgestattet_mit VALUES('Sonnenfels', 'Bowlingbahn');

CREATE SEQUENCE buchungsNR INCREMENT BY 1 START WITH 100;

INSERT INTO Buchung VALUES(buchungsNR.NextVal,
5,
TO_DATE('30.07.2021', 'DD.MM.YYYY'),
TO_DATE('22.06.2021', 'DD.MM.YYYY'),
TO_DATE('23.06.2021', 'DD.MM.YYYY'),
TO_DATE('30.06.2021', 'DD.MM.YYYY'),
100,
TO_DATE('30.06.2021', 'DD.MM.YYYY'),
450,'Sonnenschein','peter@web.de');

INSERT INTO Buchung VALUES(buchungsNR.NextVal,
3,
TO_DATE('30.04.2021', 'DD.MM.YYYY'),
TO_DATE('22.04.2021', 'DD.MM.YYYY'),
TO_DATE('23.04.2021', 'DD.MM.YYYY'),
TO_DATE('30.04.2021', 'DD.MM.YYYY'),
101,
TO_DATE('30.04.2021', 'DD.MM.YYYY'),
250,'Mondschein','august@web.de');

INSERT INTO Buchung VALUES(buchungsNR.NextVal,
4,
TO_DATE('30.01.2021', 'DD.MM.YYYY'),
TO_DATE('22.01.2021', 'DD.MM.YYYY'),
TO_DATE('23.01.2021', 'DD.MM.YYYY'),
TO_DATE('30.01.2021', 'DD.MM.YYYY'),
102,
TO_DATE('30.01.2021', 'DD.MM.YYYY'),
450,'Sternenlicht','tom@web.de');

INSERT INTO Buchung VALUES(buchungsNR.NextVal,
3,
TO_DATE('30.03.2021', 'DD.MM.YYYY'),
TO_DATE('22.03.2021', 'DD.MM.YYYY'),
TO_DATE('23.03.2021', 'DD.MM.YYYY'),
TO_DATE('30.03.2021', 'DD.MM.YYYY'),
103,
TO_DATE('30.03.2021', 'DD.MM.YYYY'),
450,'Jupiter','Anton@web.de');

INSERT INTO Buchung VALUES(buchungsNR.NextVal,
2,
TO_DATE('30.01.2021', 'DD.MM.YYYY'),
TO_DATE('22.01.2021', 'DD.MM.YYYY'),
TO_DATE('23.01.2021', 'DD.MM.YYYY'),
TO_DATE('30.01.2021', 'DD.MM.YYYY'),
104,
TO_DATE('30.01.2021', 'DD.MM.YYYY'),
450,'Mars','adolf@web.de');

INSERT INTO Buchung VALUES(buchungsNR.NextVal,
1,
TO_DATE('30.10.2021', 'DD.MM.YYYY'),
TO_DATE('22.10.2021', 'DD.MM.YYYY'),
TO_DATE('23.10.2021', 'DD.MM.YYYY'),
TO_DATE('30.10.2021', 'DD.MM.YYYY'),
105,
TO_DATE('30.10.2021', 'DD.MM.YYYY'),
450,'Sonnenfels','Tobias@web.de');

INSERT INTO Anzahlung VALUES(1, 400, 340);
INSERT INTO Anzahlung VALUES(2, 200, 341);
INSERT INTO Anzahlung VALUES(3, 310, 342);
INSERT INTO Anzahlung VALUES(4, 550, 343);
INSERT INTO Anzahlung VALUES(5, 730, 344);
INSERT INTO Anzahlung VALUES(6, 1350, 345);

--delete from Adresse;

select * from dbsys16.Buchung;
 
 
 
 
 
 