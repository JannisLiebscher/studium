GRANT SELECT, INSERT ON Adresse TO dbsys16;
GRANT SELECT ON Anzahlung TO dbsys16;
GRANT SELECT ON Ausstattung TO dbsys16;
GRANT SELECT ON Bild TO dbsys16;
GRANT SELECT, INSERT ON Buchung TO dbsys16;
GRANT SELECT ON Ferienwohnung TO dbsys16;
GRANT SELECT ON in_der_n�he_von TO dbsys16;
GRANT SELECT ON ist_ausgestattet_mit TO dbsys16;
GRANT SELECT, INSERT, UPDATE, DELETE ON Kunde TO dbsys16;
GRANT SELECT ON Land TO dbsys16;
GRANT SELECT ON Touristenattraktionen TO dbsys16;

--select * from Buchung;

select * from dbsys16.Buchung;

--select 'drop table '||table_name||' cascade constraints;' from user_tables;