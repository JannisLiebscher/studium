select f.name_ferienwohnung "Anzahl"
from Ferienwohnung f 
where NOT EXISTS 
    (select * from Buchung b
     where f.name_ferienwohnung = b.name_ferienwohnung);
     
--b----------------------------------------------------------------------------;

select distinct nachname, vorname
from kunde k, buchung b1, buchung b2
where k.mailadresse = b1.mailadresse
    and k.mailadresse = b2.mailadresse
    and b1.name_ferienwohnung = b2.name_ferienwohnung
    and not b1.buchungsnummer = b2.buchungsnummer;

--c----------------------------------------------------------------------------;

select name_ferienwohnung
from Ferienwohnung f
where f.name_land = 'Spanien'
and (select avg(bewertung) from Buchung b 
where b.name_ferienwohnung = f.name_ferienwohnung) >= 4;

--d----------------------------------------------------------------------------;

--falsch
select name_ferienwohnung, count(name_ausstattung)
from besitzt
group by name_ferienwohnung
order by count(name_ferienwohnung) desc
fetch first row only;

--richtig
CREATE VIEW anzahl (name, zaehler) AS 
select b.name_ferienwohnung, COUNT (*) 
        from besitzt b
        GROUP BY b.name_ferienwohnung;            
   
select name from anzahl
where zaehler = (select MAX(zaehler)from anzahl);

--e----------------------------------------------------------------------------;

SELECT l.name_land, COUNT(b.name_ferienwohnung) AS reservierungen
FROM Ferienwohnung f INNER JOIN Buchung b ON f.name_ferienwohnung = b.name_ferienwohnung
RIGHT OUTER JOIN Land l ON l.name_land = f.name_land
GROUP BY l.name_land
ORDER BY COUNT (b.name_ferienwohnung) DESC;

--f----------------------------------------------------------------------------;

select a.plz, count(f.name_ferienwohnung) as Anzahl
from adresse a, ferienwohnung f
where f.adress_id = a.adress_id
group by a.plz
order by count(f.name_ferienwohnung) desc;

--g----------------------------------------------------------------------------;

select f1.name_ferienwohnung, k1.vorname, k1.nachname
from Buchung b1, Buchung b2, Buchung b3, Kunde k1, Kunde k2, Ferienwohnung f1
where k1.mailadresse = b1.mailadresse 
    and k1.mailadresse != b2.mailadresse
    and k1.mailadresse != b3.mailadresse
    and k2.mailadresse != b1.mailadresse
    and k2.mailadresse = b2.mailadresse
    and k2.mailadresse = b3.mailadresse
    and b1.buchungsnummer != b2.buchungsnummer 
    and b1.buchungsnummer != b3.buchungsnummer
    and b2.buchungsnummer != b3.buchungsnummer
    and b1.bewertung = 5
    and b2.bewertung = 5
    and b3.bewertung = 5
    and b3.name_ferienwohnung = f1.name_ferienwohnung
    and b2.name_ferienwohnung = b1.name_ferienwohnung;

--h----------------------------------------------------------------------------;

select distinct b1.name_ferienwohnung
from Buchung b1, Buchung b2
where b1.anreisedatum <= b2.anreisedatum
    and b1.abreisedatum > b2.anreisedatum
    and b1.name_ferienwohnung = b2.name_ferienwohnung
    and b1.buchungsnummer != b2.buchungsnummer

--i----------------------------------------------------------------------------;

select b.name_ferienwohnung, avg(b.bewertung)
from Ferienwohnung f inner join besitzt a on a.name_ferienwohnung = f.name_ferienwohnung
left outer join Buchung b ON b.name_ferienwohnung = f.name_ferienwohnung
where f.name_land = 'Deutschland'
and a.name_ausstattung = 'Sauna'
and not exists (select buchungsnummer from Buchung b2
                where b.name_ferienwohnung = b2.name_ferienwohnung
                and (b2.abreisedatum between TO_DATE('01.11.2021', 'DD.MM.YYYY') and TO_DATE('21.11.2021', 'DD.MM.YYYY')
                or (b2.anreisedatum between TO_DATE('01.11.2021', 'DD.MM.YYYY') and TO_DATE('21.11.2021', 'DD.MM.YYYY'))
                or (b2.anreisedatum < TO_DATE('01.11.2021', 'DD.MM.YYYY') and b2.abreisedatum > TO_DATE('21.11.2021', 'DD.MM.YYYY'))))
group by b.name_ferienwohnung
order by avg(b.bewertung) desc;

