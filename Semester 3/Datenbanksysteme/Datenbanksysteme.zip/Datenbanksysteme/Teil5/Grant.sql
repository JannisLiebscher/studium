GRANT SELECT ON Adresse TO dbsys16;
GRANT SELECT ON Anzahlung TO dbsys16;
GRANT SELECT ON Ausstattungen TO dbsys16;
GRANT SELECT ON Bild TO dbsys16;
GRANT SELECT ON Buchung TO dbsys16;
GRANT SELECT ON Ferienwohnung TO dbsys16;
GRANT SELECT ON in_der_n�he_von TO dbsys16;
GRANT SELECT ON ist_ausgestattet_mit TO dbsys16;
GRANT SELECT ON Kunde TO dbsys16;
GRANT SELECT ON Land TO dbsys16;
GRANT SELECT ON Touristenattraktionen TO dbsys16;
commit;
rollback;

-- a) Wie viele Ferienwohnungen wurden noch nie gebucht?
SELECT COUNT (*) AS anzahl FROM Ferienwohnung f
WHERE NOT EXISTS (SELECT * FROM Buchung b WHERE f.name_ferienwohnung = b.name_ferienwohnung);

-- b) Welche Kunden haben eine Ferienwohnung bereits mehrmals gebucht?
SELECT DISTINCT vorname, nachname
FROM Kunde k, Buchung b1 , Buchung b2
WHERE k.mailadresse = b1.mailadresse 
AND k.mailadresse = b2.mailadresse 
AND b1.name_ferienwohnung = b2.name_ferienwohnung 
AND NOT b1.buchungsnummer = b2.buchungsnummer;

-- c) Welche Ferienwohnungen in Spanien haben durchschnittlich mehr als 4 Sterne erhalten?
SELECT name_ferienwohnung FROM Ferienwohnung f
WHERE f.name_land = 'Spanien'
AND (SELECT avg(bewertung) FROM Buchung b 
WHERE b.name_ferienwohnung = f.name_ferienwohnung) >= 4;

-- d) Welche Ferienwohnung hat die meisten Ausstattungen?
CREATE OR REPLACE VIEW anzahl(name, zaehler) 
AS 
SELECT b.name_ferienwohnung, COUNT (*) 
FROM ist_ausgestattet_mit b
GROUP BY b.name_ferienwohnung;            
                
SELECT name FROM anzahl
WHERE zaehler = (SELECT MAX(zaehler)FROM anzahl);
    
                    
-- e) Wie viele Reservierungen gibt es f�r die einzelnen L�nder?
SELECT l.name_land, COUNT(fb.buchungsnummer) AS reservierungen
FROM Land l 
LEFT OUTER JOIN (SELECT * FROM Ferienwohnung f INNER JOIN Buchung b ON f.name_ferienwohnung = b.name_ferienwohnung) fb
ON l.name_land = fb.name_land
GROUP BY l.name_land
ORDER BY COUNT (fb.buchungsnummer) DESC;

-- f) Wie viele Ferienwohnungen sind pro Stadtname gespeichert?
SELECT a.plz, COUNT (f.name_ferienwohnung) AS anzahl_FW
FROM Adresse a, Ferienwohnung f
WHERE a.adress_id = f.adress_id 
GROUP BY a.plz
ORDER BY COUNT(f.name_ferienwohnung)DESC;

-- g)   Untersuchen Sie, ob es Doppelbuchungen gibt. Geben Sie dazu alle Ferienwohnungen aus, f�r die es
--      zwei Buchungen gibt, die die Ferienwohnung am gleichen Tag reservieren. Hinweis: es ist kein
--      Problem, wenn ein Kunde die Ferienwohnung verl�sst, und am gleichen Tag ein anderer Kunde
--      einzieht.
SELECT b1.name_ferienwohnung, b1.buchungsnummer, b2.buchungsnummer FROM Buchung b1, Buchung b2  
WHERE NOT b1.buchungsnummer = b2.buchungsnummer
AND b1.name_ferienwohnung = b2.name_ferienwohnung
AND ((b1.anreisedatum <= b2.anreisedatum AND b1.abreisedatum > b2.anreisedatum)
OR (b1.anreisedatum >= b2.anreisedatum AND b1.abreisedatum > b2.anreisedatum AND b1.anreisedatum < b2.abreisedatum));

-- h)   Welche Ferienwohnungen mit Sauna sind in Spanien in der Zeit vom 1.11.2022 � 21.11.2022 noch
--      frei? Geben Sie den Ferienwohnungs-Namen und deren durchschnittliche Bewertung an.
--      Ferienwohnungen mit guten Bewertungen sollen zuerst angezeigt werden. Ferienwohnungen ohne
--      Bewertungen sollen am Ende ausgegeben werden.
SELECT b.name_ferienwohnung, avg(b.bewertung)
FROM Ferienwohnung f INNER JOIN ist_ausgestattet_mit a ON a.name_ferienwohnung = f.name_ferienwohnung
LEFT OUTER JOIN Buchung b ON b.name_ferienwohnung = f.name_ferienwohnung
WHERE f.name_land = 'Deutschland'
AND a.name_ausstattung = 'Sauna'
AND NOT EXISTS (SELECT * FROM Buchung b2
                WHERE b.name_ferienwohnung = b2.name_ferienwohnung
                AND (b2.abreisedatum > TO_DATE('01.11.2021', 'DD.MM.YYYY')
                AND b2.abreisedatum <= TO_DATE('21.11.2021', 'DD.MM.YYYY')
                OR (b2.anreisedatum >= TO_DATE('01.11.2021', 'DD.MM.YYYY')
                AND b2.anreisedatum < TO_DATE('21.11.2021', 'DD.MM.YYYY'))))
GROUP BY b.name_ferienwohnung
ORDER BY avg(b.bewertung) DESC
NULLS LAST;
