package Aufgabe7;

public class HybridQuickSort3Median {

    private static final int N = 100;                                                               //ab groeße wird mit insertionSort sortiert

    public static <T extends Comparable<T>> void quickSort(T[] a) {                                 // Ganzes Feld wird Übergeben
        quickSort(a, 0, a.length - 1);
    }

    public static <T extends Comparable<T>> void quickSort(T[] a, int li, int re) {
        swapMedian(a, li, re);
        while (re > li) {                                                                           // Bei re > li wird sortiert sonst trivial
            if ((re - li) <= N) {                                                                   // InsertionSort bei <= 100
                insertionSort(a, li, re);
                break;
            } else {
                int i = partition(a, li, re);                                                       // Teileschritt
                if (i-li < re-i) {                                                                  // Herrscheschritt
                    quickSort(a, li, i-1);
                    li = i + 1;
                } else {
                    quickSort(a, i+1, re);
                    re = i - 1;
                }
            }
        }
    }

    public static <T extends Comparable<T>> int partition(T[] a, int li, int re) {                  // Umordnung des Feldes
        T v = a[re];                                                                                // Pivotelement
        int i = li-1;                                                                               // Index läuft von "links nach rechts"
        int j = re;                                                                                 // Index von Rechts
        while (true) {
            do i++; while (a[i].compareTo(v) < 0);                                                  // Index i so lange erhöhren bis das gegebene Element größer ist als v
            do j--; while (j >= li && a[j].compareTo(v) > 0);                                       // Index j so lange erniedrigen bis das gegebene Element kleiner ist als v. // j muss immer größer als li sein
            if (i >= j)                                                                             // Abbruch sobald sich die beiden Bereiche getroffen haben.
                break;
            swap(a, i, j);                                                                          // Elemente werden vertauscht
        }
        a[re] = a[i];                                                                               // Pivotelement in die Mitte verschieben
        a[i] = v;
        return i;                                                                                   // Stelle des Pivotelement
    }

    public static <T extends Comparable<T>> void swap(T[] a, int i, int j) {
        T t = a[i];
        a[i] = a[j];
        a[j] = t;
    }

    public static <T extends Comparable<T>> void insertionSort(T[] a, int li, int re) {
        for (int i = li; i < re + 1; i++) {
            T v = a[i];
            int j = i - 1;
            while (j >= 0 && a[j].compareTo(v) > 0) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = v;
        }
    }

    public static <T extends Comparable<T>> void swapMedian(T[] a, int li, int re){
        int mid = (li+re)/2;                                                                        // Median bestimmen

        if(a[li].compareTo(a[mid]) > 0)
            swap(a, li, mid);

        if(a[li].compareTo(a[re]) > 0)
            swap(a, li, re);

        if(a[mid].compareTo(a[re]) > 0)
            swap(a, mid, re);

        swap(a, mid, re);
    }
}