package Aufgabe7;

public abstract class Card implements Comparable<Card> {

    public static class Suit {
        public final static String HEARTS = "HEARTS";
        public final static String DIAMOND = "DIAMOND";
        public final static String SPADES = "SPADES";
        public final static String CLUBS = "CLUBS";
    }
    public static class Rank {
        public final static String SEVEN = "SEVEN";
        public final static String EIGHT = "EIGHT";
        public final static String NINE = "NINE";
        public final static String TEN = "TEN";
        public final static String JACK = "JACK";
        public final static String QUEEN = "QUEEN";
        public final static String KING = "KING";
        public final static String ACE = "ACE";
    }

    public static int compareRank(String thisRank, String otherRank) {
        //sortiert wird der Rang nach: Ass > Koenig > Dame > Bube > Zehn > Neun > Acht > Sieben
        switch (thisRank) {
            case Rank.ACE: return 1;
            case Rank.KING:
                if (otherRank.equals(Rank.ACE))
                    return -1;
                return 1;
            case Rank.QUEEN:
                if (otherRank.equals(Rank.ACE) || otherRank.equals(Rank.KING))
                    return -1;
                return 1;
            case Rank.JACK:
                if (otherRank.equals(Rank.ACE) || otherRank.equals(Rank.KING) || otherRank.equals(Rank.QUEEN))
                    return -1;
                return 1;
            case Rank.TEN:
                if (otherRank.equals(Rank.SEVEN) || otherRank.equals(Rank.EIGHT) || otherRank.equals(Rank.NINE))
                    return 1;
                return -1;
            case Rank.NINE:
                if (otherRank.equals(Rank.SEVEN) || otherRank.equals(Rank.EIGHT))
                    return 1;
                return -1;
            case Rank.EIGHT:
                if (otherRank.equals(Rank.SEVEN))
                    return 1;
                return -1;
            case Rank.SEVEN: return -1;
            default:
                throw new IllegalArgumentException();
        }
    }
}