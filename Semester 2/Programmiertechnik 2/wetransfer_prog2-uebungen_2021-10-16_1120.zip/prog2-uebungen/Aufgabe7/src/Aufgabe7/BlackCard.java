package Aufgabe7;

import java.util.Random;

public class BlackCard extends Card {

    private String suit;
    private String rank;

    public BlackCard(String suit, String rank) {
        if (isBlackCard(suit, rank)) {
            this.suit = suit;
            this.rank = rank;
        }
    }

    public BlackCard() {
        this.suit = randBlackSuit();
        this.rank = randBlackRank();
    }

    private String randBlackSuit() {
        Random rand = new Random();
        if (rand.nextInt() % 2 == 0) {
            return Suit.CLUBS;
        } else {
            return Suit.SPADES;
        }
    }

    private String randBlackRank() {
        Random rand = new Random();
        if (rand.nextInt() % 2 == 0) {
            if (rand.nextInt() % 2 == 0) {
                if (rand.nextInt() % 2 == 0)
                    return Rank.ACE;
                return Rank.KING;
            } else {
                if (rand.nextInt() % 2 == 0)
                    return Rank.QUEEN;
                return Rank.JACK;
            }
        } else {
            if (rand.nextInt() % 2 == 0) {
                if (rand.nextInt() % 2 == 0)
                    return Rank.TEN;
                return Rank.NINE;
            } else {
                if (rand.nextInt() % 2 == 0)
                    return Rank.EIGHT;
                return Rank.SEVEN;
            }
        }
    }

    public String getSuit() {
        return this.suit;
    }

    public String getRank() {
        return this.rank;
    }

    public boolean isBlackCard(String suit, String rank) {
        switch (suit) {
            case Suit.SPADES:
            case Suit.CLUBS:
                break;
            default:
                throw new IllegalArgumentException();
        }
        switch (rank) {
            case Rank.ACE:
            case Rank.KING:
            case Rank.QUEEN:
            case Rank.JACK:
            case Rank.TEN:
            case Rank.NINE:
            case Rank.EIGHT:
            case Rank.SEVEN:
                break;
            default:
                throw new IllegalArgumentException();
        }
        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (obj instanceof BlackCard) {
            BlackCard i = (BlackCard) obj;
            return i.getSuit().equals(this.getSuit()) && i.getRank().equals(this.getRank());
        }
        return false;
    }

    @Override
    public String toString() {
        return "{" + this.getRank() + " of " + this.getSuit() + "}";
    }

    @Override
    public int compareTo(Card o) {
        //sortiert wird die Farbe nach: Piq > Kreuz
        if (this.equals(o))
            return 0;
        if (o instanceof BlackCard) {
            BlackCard i = (BlackCard) o;
            if (this.getSuit().equals(Suit.SPADES) && i.getSuit().equals(Suit.CLUBS)) {
                return 1;
            } else if (this.getSuit().equals(Suit.CLUBS) && i.getSuit().equals(Suit.SPADES)) {
                return -1;
            } else {
                return compareRank(this.getRank(), i.getRank());
            }
        } else if (o instanceof RedCard) {// this = Schwarz < o = Rot
            return -1;
        }
        throw new IllegalArgumentException();
    }
}
