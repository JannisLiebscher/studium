package Aufgabe7;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Arrays;

public class HybridQuickSortTest {

    static int SekundenFaktor = 1000;   //(1000 für Sekunden) == (1 für msec)

    public static void main(String[] args) throws IOException {

        // Quicksort von 200 Zahlen + Ausgabe der CPU-Zeit
        long startTotal = System.nanoTime();
        long start = System.nanoTime();

        Integer[] intArr = {131, 563, 104, 709, 772, 521, 67, 53, 963, 992, 923, 770, 998, 727, 493, 840, 572, 837, 832, 550, 729, 386, 738, 160, 987, 225, 43, 994, 860, 954, 483, 677, 186, 111, 343, 543, 110, 878, 364, 683, 962, 129, 70, 575, 88, 597, 103,
                291, 434, 380, 530, 520, 601, 763, 436, 90, 278, 51, 606, 858, 58, 833, 966, 628, 365, 546, 827, 469, 533, 347, 686, 246, 317, 991, 460, 982, 45, 647, 903, 319, 863, 762, 177, 450, 791, 588, 534, 897, 558, 41, 308, 198, 715, 711, 904, 116, 475,
                965, 612, 619, 120, 37, 169, 23, 273, 872, 780, 31, 746, 690, 990, 473, 773, 706, 887, 753, 14, 388, 513, 592, 124, 5, 251, 783, 843, 165, 91, 252, 361, 789, 544, 857, 60, 846, 750, 178, 879, 902, 680, 968, 936, 555, 699, 545, 812, 498, 8, 761,
                907, 836, 492, 72, 470, 719, 529, 329, 441, 80, 335, 646, 413, 44, 221, 78, 12, 988, 642, 671, 523, 698, 337, 440, 162, 985, 760, 501, 993, 582, 590, 455, 825, 404, 153, 406, 150, 326, 574, 422, 203, 569, 673, 687, 945, 92, 219, 542, 426, 803, 712, 381};
        HybridQuickSort.quickSort(intArr);
        //System.out.println(Arrays.toString(intArr));

        long end = System.nanoTime();
        double elapsedTime = (double)(end - start)/1.0e06/SekundenFaktor;
        System.out.printf("Elapsed time QuickSort in: %.3f sec%n", elapsedTime);


        //QuickSort3Median von 200 Zahlen + Ausgabe der CPU-Zeit
        long start3Median = System.nanoTime();

        HybridQuickSort3Median.quickSort(intArr);
        //System.out.println(Arrays.toString(intArr));

        long end3Median = System.nanoTime();
        double elapsedTime3Median = (double) (end3Median - start3Median)/1.0e06/SekundenFaktor;
        System.out.printf("Elapsed time QuickSort3Median in: %.3f sec%n", elapsedTime3Median);
        //QuickSort3Median von 200 Zahlen + Ausgabe der CPU-Zeit


        //QuickSort von 20 Zufaelligen Zahlen + Ausgabe der CPU-Zeit
        long start2 = System.nanoTime();

        Integer[] randArray = randArr(10000, 1000000);
        HybridQuickSort.quickSort(randArray);
        Arrays.sort(randArray);
            //System.out.println(Arrays.toString(randArray));

        long end2 = System.nanoTime();
        double elapsedTime2 = (double)(end2 - start2)/1.0e06/SekundenFaktor;
        System.out.printf("Quicksort Random Numbers in: %.3f sec%n", elapsedTime2);
        //QuickSort von 20 Zufaelligen Zahlen + Ausgabe der CPU-Zeit


        //QuickSort3Median von 20 Zufaelligen Zahlen + Ausgabe der CPU-Zeit
        long start3Median2 = System.nanoTime();

        Integer[] randArray2 = randArr(10000, 1000000);
        HybridQuickSort3Median.quickSort(randArray2);
        Arrays.sort(randArray);
            //System.out.println(Arrays.toString(randArray));

        long end3Median2 = System.nanoTime();
        double elapsedTime3Median2 = (double)(end3Median2 - start3Median2)/1.0e06/SekundenFaktor;
        System.out.printf("QuickSort3Median Random Numbers in: %.3f sec%n", elapsedTime3Median2);
        //QuickSort3Median von 20 Zufaelligen Zahlen + Ausgabe der CPU-Zeit


        //Kafka_Der_Prozess Ausgabe
    text();

    long endTotal = System.nanoTime();
    double elapsedTimeTotal = (double) (endTotal - startTotal)/1.0e06/SekundenFaktor;
        System.out.printf("Total Elapsed time in: %.3f sec%n", elapsedTimeTotal);

    }

    private static Integer[] randArr(int max, int length) {
        Integer[] array = new Integer[length];
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * max);
        }
        return array;
    }

    private static void text() throws IOException {
        long start = System.nanoTime();

        ArrayList<String> s = new ArrayList<>();
        LineNumberReader in;
        in = new LineNumberReader(new FileReader("C:\\Studium\\Programmiertechnik-Java\\prog2-uebungen\\Aufgabe7\\src\\Aufgabe7\\Kafka_Der_Prozess.txt"));
        String line;
        while ((line = in.readLine()) != null) {
            String[] wf = line.split("[^a-z^A-Z^ÃŸ^Ã¤^Ã¶^Ã¼^Ã„^Ã–^Ãœ]+");
            for (String w: wf) {
                if (w.length() == 0 || w.length() == 1)
                    continue;
                s.add(w);
            }
        }
        String[] l = s.toArray(new String[]{});
        HybridQuickSort.quickSort(l);

        long end = System.nanoTime();
        double elapsedTime = (double)(end-start)/1.0e06/SekundenFaktor;
        //System.out.println(Arrays.toString(l));
        System.out.printf("Text Time: %.3f sec%n", elapsedTime);
    }
}