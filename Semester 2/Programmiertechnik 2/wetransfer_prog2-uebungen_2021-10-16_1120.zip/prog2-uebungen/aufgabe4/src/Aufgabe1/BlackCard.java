package Aufgabe1;

import java.util.Random;

public class BlackCard extends Card{
    private final Suit suit;
    private final Rank rank;

    public BlackCard() {
        Random rand = new Random();
        int r = rand.nextInt(8);

        switch (r) {
            case 0 -> rank = Rank.SEVEN;
            case 1 -> rank = Rank.EIGHT;
            case 2 -> rank = Rank.NINE;
            case 3 -> rank = Rank.TEN;
            case 4 -> rank = Rank.JACK;
            case 5 -> rank = Rank.QUEEN;
            case 6 -> rank = Rank.KING;
            case 7 -> rank = Rank.ACE;
            default -> throw new IllegalStateException("Unexpected value: " + r);
        }
        if (rand.nextInt() % 2 == 0) suit = Suit.CLUBS;
        else suit = Suit.SPADES;
    }
    public BlackCard(Suit s, Rank r) {
        if (!s.equals(Suit.CLUBS) && !s.equals(Suit.SPADES))
            throw new IllegalArgumentException();
        suit = s;
        rank = r;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BlackCard blackCard = (BlackCard) o;
        return suit == blackCard.suit && rank == blackCard.rank;
    }

    @Override
    public String toString() { return rank +" of "+ suit; };
}
