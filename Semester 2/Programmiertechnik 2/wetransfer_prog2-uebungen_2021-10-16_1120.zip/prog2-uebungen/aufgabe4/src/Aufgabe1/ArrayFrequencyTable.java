package Aufgabe1;


import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author Tobias Latt
 * @since 24.03.2021
 */
public class ArrayFrequencyTable<T> extends AbstractFrequencyTable<T> {
	private int size;
	private int modCount = 0;
	private Element<T>[] fqTable;
	private final int DEFAULT_SIZE = 100;

	public ArrayFrequencyTable() {
		clear();
	}

	@Override
	public Iterator<Element<T>> iterator() {
		return new ArrayListIterator();
	}

	private class ArrayListIterator implements Iterator<Element<T>> {
		private int current = -1;
		private final int expectedMod = modCount;

		@Override
		public boolean hasNext() {
			return current != size() - 1;
		}

		@Override
		public Element<T> next() {
			if (expectedMod != modCount)
				throw new ConcurrentModificationException();
			if (!hasNext())
				throw new NoSuchElementException();
			++current;
			return fqTable[current];
		}
	}

	public int size() {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		return this.size;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final void clear() {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet.");
		// To change body of generated methods, choose Tools | Templates.
		// Ihr Code:
		// ...
		this.size = 0;
		modCount++;
		this.fqTable = (Element<T>[]) new Element[DEFAULT_SIZE];
	}


	private void moveLeft(int pos) {
		Element<T> e = this.fqTable[pos];
		int i = pos - 1;
		while(i >= 0 && e.getFrequency() > this.fqTable[i].getFrequency()) {
			this.fqTable[i+1] = this.fqTable[i];
			i--;
		}
		this.fqTable[i+1] = e;
	}


	@Override
	public void add(T e, int f) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		if (e == null || f <= 0) {
			throw new IllegalArgumentException();
		}

		for (int i = 0; i < this.size(); i++) {
			if (this.fqTable[i].getData().equals(e)) {
				this.fqTable[i].addFrequency(f);
				this.moveLeft(i);
				modCount++;
				return;
			}
		}
		//Array wird vergrößert
		if (this.size() == this.fqTable.length) {
			this.fqTable = Arrays.copyOf(this.fqTable, 2*this.size());
		}

		//Ist das Wort noch nicht vorhanden, wird es als neuer Eintrag hinzugefügt
		this.fqTable[this.size()] = new Element<T>(e, f);
		if (this.size() > 0) {
			this.moveLeft(this.size());
		}
		//In diesem Fall muss die Größe angepasst werden
		this.size++;
		modCount++;
	}

	@Override
	public void add(T e) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		this.add(e, 1);
	}

	@Override
	public Element<T> get(int pos) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		if (pos < 0 || pos > this.size() - 1) {
			throw new IllegalArgumentException();
		}
		return this.fqTable[pos];
	}

	@Override
	public int get(T data) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code:
		// ...
		for (int i = 0; i < this.size(); i++) {
			if (this.fqTable[i].getData().equals(data)) {
				return this.fqTable[i].getFrequency();
			}
		}
		return 0;
	}
}