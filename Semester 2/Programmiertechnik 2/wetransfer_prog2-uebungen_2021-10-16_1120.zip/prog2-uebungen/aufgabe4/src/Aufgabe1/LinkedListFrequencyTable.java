package Aufgabe1;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Realisiert Häufigkeitstabellen für Wörter als linear-verkettete Liste
 * Die Worte werden nach absteigender Häufigkeit sortiert
 * @author oliverbittel
 * @author Tobias Latt
 * @since 04.03.2021
 */
public class LinkedListFrequencyTable<T> extends AbstractFrequencyTable<T> {
    //private Instanzvariable; gibt Zahl der Elemente an
    private int size = 0;
    private int modCount = 0;
    //Feld aus Wort-Häufgikeit-Paaren | geordnet nach absteigender Häufigket
    private Node begin;
    private Node end;

    @Override
    public Iterator<Element<T>> iterator() {
        return new LinkedListIterator();
    }

    private class LinkedListIterator implements Iterator<Element<T>> {
        private Node current = begin;
        private final int expectedMod = modCount;

        @Override
        public boolean hasNext() {
            return current.next.next != null;
        }

        @Override
        public Element<T> next() {
            if (expectedMod != modCount)
                throw new ConcurrentModificationException();
            if (!hasNext())
                throw new NoSuchElementException();
            current = current.next;
            return current.data;
        }
    }

    public LinkedListFrequencyTable() {
        clear();
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public final void clear() {
        begin = new Node(null, null, null);
        end = new Node(null, null, begin);
        begin.next = end;
        //end.prev = begin;
        size = 0;
        modCount++;
    }

    @Override
    public void add(T data, int f) {
        Node p = begin;
        while (p.next != end) {
            if (p.next.data.getData().equals(data)) {
                p.next.data.addFrequency(f);
                moveLeft(p.next);
                modCount++;
                return;
            }
            p = p.next;
        }
        Node r = new Node(new Element<>(data, f), p.next, p);
        r.next.prev = r;
        p.next = r;
        size++;
        moveLeft(r);
        modCount++;
    }

    @Override
    public Element<T> get(int pos) {
        Node p = begin.next;
        int i = 0;
        while (i < pos) {
            p = p.next;
            i++;
        }
        return p.data;
    }

    
    @Override
    public int get(T data) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (data == null || data.equals("")) {
            throw new IllegalArgumentException();
        }
        for (Node p = begin; p.next.next != null; p = p.next) {
            if (p.next.data.getData().equals(data)) {
                return p.next.data.getFrequency();
            }
        }
        return 0;
    }

    private void moveLeft(Node x) {
        Node y = x.prev;
        while(y.data != begin.data) {
            if(x.data.getFrequency() > y.data.getFrequency()) {
                x.next.prev = y;
                y.next = x.next;
                y.prev.next = x;
                x.prev = y.prev;
                x.next = y;
                y.prev = x;
                y = x.prev;

            } else {
                break;
            }

        }
    }

    private class Node {      // cannot be referenced from a static context?
        private Node next;
        private Node prev;
        private Element<T> data;

        Node(Element<T> x, Node n, Node p) {
            this.data = x;
            this.next = n;
            this.prev = p;
        }
    }
}
