package Aufgabe1;

/**
 *
 * @author Tobias Latt
 * @since 24.03.2021
 */
public abstract class AbstractFrequencyTable<T> implements FrequencyTable<T> {
	@Override
	public boolean isEmpty() {
		return this.size() == 0;
	}

	@Override
    public void add(T data) {
        add(data, 1);
    }

	@Override
	public void addAll(FrequencyTable<? extends T> fq) {
		if (fq != null) {
			/*for (int i = 0; i < fq.size(); i++) {
				this.add(fq.get(i).getData(),       				//Element mit Daten und Häufigkeit aus fq nehmen und
						fq.get(i).getFrequency()); 					//in this "AbstractFrequencyTable" speichern
			} */
			for(Element<?> data: fq)
				this.add((T) data.getData(), data.getFrequency());
		}
	}
	@Override
	public void collectMostFrequent(FrequencyTable<? super T> fq) {
		//fq leeren, um Elemente aus this unverfälscht darin speichern zu können
		fq.clear();
		//lokale Variable most für höchste frequency
		int most = this.get(0).getFrequency();  					//this.get(0), da absteigend sortiert

		/* for (int i = 0; i < this.size(); i++) {         			//läuft von links über size
			if (this.get(i).getFrequency() == most) {   			//sucht nach Elementen, die alle die Frequency des linkesten
				fq.add(this.get(i).getData(), most);   				//Wortes besitzen und speichert sie in fq
			} else {
				return;                                				//Bricht ab, sobald Worte mit geringerer Häufigkeit auftreten
			} */
		for (Element<T> data : this) {
			if (data.getFrequency() == most)
					fq.add(data.getData(), data.getFrequency());
			else {
				return;
			}
		}
	}


	@Override
	public void collectLeastFrequent(FrequencyTable<? super T> fq) {
		fq.clear();
		/* for (int i = 0; i < this.size(); i++) {
			if (this.get(i).getFrequency() == 1) {
				fq.add(this.get(i).getData(), 1);
			}
		} */
		for(Element<T> x : this) {
			if(x.getFrequency() == 1) {
				fq.add(x.getData(), 1);
			}
		}
	}

	/**
	 * Liefert eine String-Darstellung zur&uuml;ck.
	 * @return String-Darstellung.
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		int size = this.size();
		s.append("{");
		/* for(int i = 0; i < this.size(); i++) {
			s.append(this.get(i).toString() + ", ");
		}
		*/
		for(Element<T> data : this)
			s.append(data.toString()).append(", ");
		s.append("} size = ").append(size);
		return s.toString();
	}
}