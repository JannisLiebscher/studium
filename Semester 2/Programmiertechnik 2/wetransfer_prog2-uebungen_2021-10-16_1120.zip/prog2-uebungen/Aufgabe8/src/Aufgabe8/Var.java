package Aufgabe8;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;

public class Var implements Expression{

    private final String variable;

    public Var(String variable) {
        this.variable = variable;
    }

    @Override
    public double eval(Map<String, Double> map) {
        if(!map.containsKey(this.variable)) {
            throw new NoSuchElementException();
        }
        return (double)map.get(this.variable);
    }

    @Override
    public Set<String> getVars() {
        Set<String> s = new TreeSet<>();
        s.add(this.variable);
        return s;
    }

    @Override
    public String toString() {
        return this.variable;
    }

}