package Aufgabe8;

import java.util.Map;

public class Product extends CompoundExpression{

    public Product(Expression firstVar, Expression secondVar) {
        this.firstVar = firstVar;
        this.secondVar = secondVar;
    }

    @Override
    public double eval(Map<String, Double> map) {
        return firstVar.eval(map) * secondVar.eval(map);
    }

    @Override
    public String toString() {
        return "(" + firstVar.toString() + " * " + secondVar.toString() + ")";
    }
}