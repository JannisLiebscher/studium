package Aufgabe8;

import java.util.Set;
import java.util.TreeSet;

public abstract class CompoundExpression implements Expression{
    public Expression firstVar;
    public Expression secondVar;

    @Override
    public Set<String> getVars() {
        Set<String> s = new TreeSet<>();
        if(firstVar.getVars() != null) {
            s.addAll(firstVar.getVars());
        }
        if(secondVar.getVars() != null) {
            s.addAll(secondVar.getVars());
        }
        return s;
    }
}
