/*  Interface
    1-n association with ZusammengesetzteTaetigkeit
    ElementareTaetigkeit & ZusammengesetzteTaetigkeit are child elements
    of Taetigkeit
*/

public interface Taetigkeit
{
  /* Method Signatures */
  double getTime();
  void add(Taetigkeit t);
  void remove(Taetigkeit t);
  int getAnzahl();
}
