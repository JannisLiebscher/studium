/*    ElementareTaetigkeit
      Child element of Taetigkeit
*/
public class ElementareTaetigkeit implements Taetigkeit
{//ElementareTaetigkeit
  private String beschr;
  private double time;

  ElementareTaetigkeit(String b, double t)
  {
    beschr = b;
    time = t;
  }

  /* Implementation Of Method Signatures */
  @Override
  public double getTime()
  {//getTime
    return time;
  }//getTime
  @Override
  public void add(Taetigkeit t)
  {//add
    throw new UnsupportedOperationException();
  }//add
  @Override
  public void remove(Taetigkeit t)
  {//remove
    throw new UnsupportedOperationException();
  }//remove
  @Override
  public int getAnzahl()
  {//getAnzahl
    return 1;
  }//getAnzahl
}//ElementareTaetigkeit
