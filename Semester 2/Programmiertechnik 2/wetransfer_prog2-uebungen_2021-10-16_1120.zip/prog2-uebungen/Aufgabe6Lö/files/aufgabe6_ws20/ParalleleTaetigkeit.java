public class ParalleleTaetigkeit extends ZusammengesetzteTaetigkeit
{//ParalleleTaetigkeit
  @Override
  public double getTime()
  {
    double x = 0;
    for (Taetigkeit t : meineTaetigkeiten)
    {
      if (t.getTime() > x)
        x = t.getTime();
    }
    return x;
  }
}//ParalleleTaetigkeit
