
import java.util.ArrayList;
/*   ZusammengesetzteTaetigkeit
     n-1 association with Taetigkeit - Child element of Taetigkeit
*/

abstract class ZusammengesetzteTaetigkeit implements Taetigkeit
/* Abstract Classes dont have to implement all methods of inheritance */
{//ZusammengesetzteTaetigkeit
  /* two dimensional list */
  protected ArrayList<Taetigkeit> meineTaetigkeiten = new ArrayList<>();
  @Override
  public void add(Taetigkeit tk)
  {
    meineTaetigkeiten.add(tk);
  }
  @Override
  public void remove(Taetigkeit tk)
  {
    meineTaetigkeiten.remove(tk);
  }
  @Override
  public int getAnzahl()
  {
    int anzahl = 0;
    for (Taetigkeit o : meineTaetigkeiten)
    {
      anzahl += o.getAnzahl();
    }
    return anzahl;
  }
  //public double getTime(); override in both child
}//ZusammengesetzteTaetigkeit
