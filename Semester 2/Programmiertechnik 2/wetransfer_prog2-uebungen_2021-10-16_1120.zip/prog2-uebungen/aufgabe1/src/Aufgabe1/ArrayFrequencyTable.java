package Aufgabe1;

import java.util.Arrays;

/**
 *
 * @author Tobias Latt
 * @since 24.03.2021
 */
public class ArrayFrequencyTable extends AbstractFrequencyTable {
	private int size;
	private Word fqTable[];
	private final int DEFAULT_SIZE = 100;

	public ArrayFrequencyTable() {
		clear();
	}

	public int size() {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		return this.size;
	}

	@Override
	public final void clear() {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code:
		// ...
		this.size = 0;
		fqTable = new Word[DEFAULT_SIZE];
	}


	// Sortieren des Arrays
	private void moveLeft(int pos) {
		Word w = fqTable[pos];
		while (pos > 0 && w.getFrequency() > fqTable[pos - 1].getFrequency()) {
			fqTable[pos] = fqTable[pos - 1];
			pos--;
		}
		fqTable[pos] = w;
	}


	@Override
	public void add(String w, int f) {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code: 
		// ...
		if(size() == fqTable.length) {
			fqTable = Arrays.copyOf(fqTable, fqTable.length + DEFAULT_SIZE);
		}
		for (int i = 0; i < fqTable.length; i++) {
			if (fqTable[i] != null && w.equals(fqTable[i].getWord())) {
				fqTable[i].addFrequency(f);
				moveLeft(i);
				return;
			} else if (fqTable[i] == null) {
				fqTable[i] = new Word(w, f);
				this.size++;
				moveLeft(i);
				return;
			}
		}
	}

	@Override
	public void add(String w) {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code: 
		// ...
		if(size() == fqTable.length) {
			fqTable = Arrays.copyOf(fqTable, fqTable.length + DEFAULT_SIZE);
		}
		for (int i = 0; i < fqTable.length; i++) {
			if (fqTable[i] != null && w.equals(fqTable[i].getWord())) {
				fqTable[i].addFrequency(1);
				moveLeft(i);
				return;
			} else if (fqTable[i] == null) {
				fqTable[i] = new Word(w, 1);
				this.size++;
				moveLeft(i);
				return;
			}
		}
	}

	@Override
	public Word get(int pos) {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code: 
		// ...
		return fqTable[pos];
	}

	@Override
	public int get(String w) {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code: 
		// ...
		for (int i = 0; i < size; i++) {
			if (w.equals(fqTable[i].getWord()) && this.fqTable[i] != null) {
				return fqTable[i].getFrequency();
			}
		}
		return 0;
	}
}