 public class Box<T> {
private T x;

         public void put(T x) {this.x = x;}
 public T get() {return this.x;}

        public void put(Box<T> b) {
        this.x = b.get();
         }
 public void get(Box<T> b) {
        b.put(this.x);
         }

         public static void main(String[] args) {
         Box<Number> nbBox = new Box<>();
        nbBox.put(17);
        System.out.println(nbBox.get());

         Box b = new Box();
         b.put("abc");

       Box<Number> nbBox1 = new Box<>();
        nbBox1.put(4);
         Box<Number> nbBox2 = new Box<>();
         nbBox2.put(nbBox1);
         System.out.println(nbBox2.get());
         nbBox2.put(9);
         nbBox2.get(nbBox1);
         System.out.println(nbBox1.get());

         Box<Integer> intBox = new Box<>();
         nbBox.put(nbBox);
         intBox.get(intBox);
         }
 }
