// O. Bittel
// 10.03.2017

package Aufgabe10;

import javax.swing.*;
import java.util.*;
import java.util.Map.Entry;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class TelefonBuch {

    private TreeMap<String,String> telBuch = new TreeMap<>();

    public boolean insert(String name, String zusatz, String telNr) {
        String tmp = name + " " + zusatz;
        if (telBuch.containsKey(tmp) && telBuch.containsValue(telNr)) {
            return false;
        }
        telBuch.put(tmp,telNr);

        if (TelefonBuchGUI.getMyFrame() != null) {
            TelefonBuchGUI.getMyFrame().getField().append(tmp + " " + telNr + '\n');
        }
        return true;
    }

    public boolean remove(String name, String zusatz) {
        String tmp = name + " " + zusatz;

        boolean right = telBuch.remove(tmp, telBuch.get(tmp));

        if (right == true) {
            if (TelefonBuchGUI.getMyFrame() != null) {
                TelefonBuchGUI.getMyFrame().getField().append(name + " " + zusatz + " wurde gelöscht" + '\n');
            }
        }
        return right;
    }

    public String exactSearch(String name, String zusatz) {

        String telNr;
        if ((telNr = telBuch.get(name + " " + zusatz)) != null) {
            return telNr;
        }
        return null;
    }

    public List<String> prefixSearch(String str) {
        List<String> tmp = new LinkedList<>();

        for (Entry<String,String> eintrag
                : telBuch.subMap(str, true, sumToCharsAtString(str),false).entrySet()) {
            String wert = eintrag.getKey() + " " + eintrag.getValue();
            tmp.add(wert);
        }
        return tmp;
    }

    private String sumToCharsAtString(String word) {
        StringBuilder b = new StringBuilder();

        char[] chars = word.toCharArray();
        for (char c : chars) {
            if(c != ' ') {
                c = (char) (c + 1);
            }
            b.append(c);
        }
        return b.toString();
    }

    public void read(File f) {
        LineNumberReader in = null;
        try {
            telBuch.clear();
            in = new LineNumberReader(new FileReader(f));
            String line;
            while ((line = in.readLine()) != null) {
                String[] sf = line.split(" ");
                if (sf.length == 2) {
                    insert(sf[0], "", sf[1]); // leerer Zusatz
                } else if (sf.length == 3) {
                    insert(sf[0], sf[1], sf[2]);
                }
            }
            in.close();
        } catch (IOException ex) {
            Logger.getLogger(TelefonBuch.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void save(File f) {
        PrintWriter out = null;
        try {
            out = new PrintWriter(f);
            for (Entry<String, String> eintrag : telBuch.entrySet()) {
                String s = eintrag.getKey().replace('#', ' ') + " " + eintrag.getValue();
                out.println(s);
            }
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(TelefonBuch.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void print(List<String> strList) {
        for (String s : strList)
            System.out.println(s);
    }

    public static void main(String[] args)
            throws FileNotFoundException, IOException {

        TelefonBuch telBuch = new TelefonBuch();
        telBuch.read(new File("C:\\Users\\User\\OneDrive\\Desktop\\Informatik\\2. Semester\\Programmiertechnik 2\\src\\Aufgabe11TelefonBuch\\TelBuchMit420Namen.txt"));

        System.out.println(telBuch.exactSearch("Oliver",""));
        System.out.println();

        print(telBuch.prefixSearch("H"));
        System.out.println();

        print(telBuch.prefixSearch(""));
        System.out.println();

        telBuch.insert("Oliver","1","33245");
        telBuch.insert("Oliver","2","23423");
        telBuch.insert("Oliver","3","87655");
        telBuch.remove("Oliver","2");

        print(telBuch.prefixSearch("Ol"));
        System.out.println();

        telBuch.save(new File("test.txt"));
    }
}