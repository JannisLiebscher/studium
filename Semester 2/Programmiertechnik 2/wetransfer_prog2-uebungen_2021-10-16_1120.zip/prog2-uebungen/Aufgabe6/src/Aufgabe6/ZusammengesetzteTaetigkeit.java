package Aufgabe6;

import java.util.ArrayList;

abstract class ZusammengesetzteTaetigkeit implements Taetigkeit
{
    protected ArrayList<Taetigkeit> meineTaetigkeiten = new ArrayList<>();
    @Override
    public void add(Taetigkeit tk)
    {
        meineTaetigkeiten.add(tk);
    }
    @Override
    public void remove(Taetigkeit tk)
    {
        meineTaetigkeiten.remove(tk);
    }
    @Override
    public int getAnzahl()
    {
        int anzahl = 0;
        for (Taetigkeit o : meineTaetigkeiten)
        {
            anzahl += o.getAnzahl();
        }
        return anzahl;
    }
}

