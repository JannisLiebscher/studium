package Aufgabe6.bibliothek;

public class Buch {

    private final String name;
    private Person entleiher;

    public Buch(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public Person getEntleiher(){
        return this.entleiher;
    }

    public boolean wirdAusgeliehen(Person p){
        if (this.getEntleiher() != null)
            return false;
        this.entleiher = p;
        p.leihtAus(this);
        return true;
    }

    public boolean wirdZurueckGegeben(){
        if (this.entleiher == null)
            return false;
        Person p = this.entleiher;
        this.entleiher = null;
        p.gibtZurueck(this);
        return true;
    }

    public void print() {
        if (this.entleiher != null) {
            System.out.println(this.getName() + " wird von " + this.entleiher.getName() + " ausgeliehen");
        } else {
            System.out.println(this.getName() + " wird von keinem ausgeliehen");
        }
    }
}