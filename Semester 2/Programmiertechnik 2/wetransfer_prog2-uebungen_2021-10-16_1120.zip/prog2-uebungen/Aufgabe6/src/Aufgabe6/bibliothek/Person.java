package Aufgabe6.bibliothek;

import java.util.LinkedList;
import java.util.List;

public class Person {

    private final String name;
    private final List<Buch> ausgelieheneBuecher = new LinkedList<>();

    public Person(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public boolean leihtAus(Buch b){
        if (ausgelieheneBuecher.contains(b))
            return false;
        if (b.getEntleiher() != null && b.getEntleiher() != this)
            return false;
        ausgelieheneBuecher.add(b);
        b.wirdAusgeliehen(this);
        return true;
    }

    public boolean gibtZurueck(Buch b){
        if (!ausgelieheneBuecher.contains(b))
            return false;
        ausgelieheneBuecher.remove(b);
        b.wirdZurueckGegeben();
        return true;
    }

    public void print(){
        if (ausgelieheneBuecher.size() == 0)
            return;
        StringBuilder s = new StringBuilder();
        s.append(this.getName()).append(" hat folgende Buecher ausgeliehen: ");
        for (Buch x : ausgelieheneBuecher) {
            s.append(x.getName()).append("; ");
        }
        System.out.println(s);
    }
}