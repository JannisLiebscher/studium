package Aufgabe6;

public class Taetigkeit_Test
{
    public static void main(String[] args)
    {
        Taetigkeit tk1 = new ParalleleTaetigkeit();   //Constructor
        /* Add Two Processes */
        tk1.add(new ElementareTaetigkeit("Linke Seitenwand montieren", 5.0));
        tk1.add(new ElementareTaetigkeit("Rechte Seitenwand montieren", 5.0));

        Taetigkeit tk2 = new ParalleleTaetigkeit(); //Constructor
        /* Add Two Processes */
        tk2.add(new ElementareTaetigkeit("Linke Türe montieren", 7.0));
        tk2.add(new ElementareTaetigkeit("Rechte Türe mit Griff montieren", 9.0));

        // Constructing the whole process (seriell)
        Taetigkeit schrankMontage = new SerielleTaetigkeit();
        schrankMontage.add(new ElementareTaetigkeit("Füße an den Boden montieren", 6.0));
        schrankMontage.add(tk1);
        schrankMontage.add(new ElementareTaetigkeit("Decke montieren", 8.0));
        schrankMontage.add(tk2);
        // Print Stuff
        System.out.println(schrankMontage.getTime()+ " min"); //should be 28
        System.out.println(schrankMontage.getAnzahl()); //6
    }
}