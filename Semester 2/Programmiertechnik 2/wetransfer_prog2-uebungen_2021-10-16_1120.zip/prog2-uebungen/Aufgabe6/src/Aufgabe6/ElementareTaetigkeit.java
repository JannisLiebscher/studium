package Aufgabe6;
public class ElementareTaetigkeit implements Taetigkeit
{
    private String beschr;
    private double time;

    ElementareTaetigkeit(String b, double t)
    {
        beschr = b;
        time = t;
    }
    @Override
    public double getTime()
    {
        return time;
    }
    @Override
    public void add(Taetigkeit t)
    {
        throw new UnsupportedOperationException();
    }
    @Override
    public void remove(Taetigkeit t)
    {
        throw new UnsupportedOperationException();
    }
    @Override
    public int getAnzahl()
    {
        return 1;
    }
}