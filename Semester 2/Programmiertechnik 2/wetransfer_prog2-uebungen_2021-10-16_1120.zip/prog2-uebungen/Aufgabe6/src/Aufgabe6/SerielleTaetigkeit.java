package Aufgabe6;

public class SerielleTaetigkeit extends ZusammengesetzteTaetigkeit
{
    @Override
    public double getTime()
    {
        double x = 0;
        for (Taetigkeit t : meineTaetigkeiten)
        {
            x += t.getTime();
        }
        return x;
    }
}
