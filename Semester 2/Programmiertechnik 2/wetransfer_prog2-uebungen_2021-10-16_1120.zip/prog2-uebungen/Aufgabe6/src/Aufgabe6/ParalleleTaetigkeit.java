package Aufgabe6;

public class ParalleleTaetigkeit extends ZusammengesetzteTaetigkeit
{
    @Override
    public double getTime()
    {
        double x = 0;
        for (Taetigkeit t : meineTaetigkeiten)
        {
            if (t.getTime() > x)
                x = t.getTime();
        }
        return x;
    }
}
