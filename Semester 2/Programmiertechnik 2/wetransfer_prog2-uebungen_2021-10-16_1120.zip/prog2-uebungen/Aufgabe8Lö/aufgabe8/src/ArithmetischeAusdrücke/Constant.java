package ArithmetischeAusdrücke;

import java.util.Map;
import java.util.Set;

public class Constant implements Expression{

    private final double constant;

    public Constant(double constant) {
        this.constant = constant;
    }

    @Override
    public double eval(Map<String, Double> map) {
        return this.constant;
    }

    @Override
    public Set<String> getVars() {
        return null;
    }

    @Override
    public String toString() {
        return Double.toString(this.constant);
    }
}
