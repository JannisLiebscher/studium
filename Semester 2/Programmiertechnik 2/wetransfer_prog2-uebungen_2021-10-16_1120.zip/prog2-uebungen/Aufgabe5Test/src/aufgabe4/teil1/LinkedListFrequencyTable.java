package aufgabe4.teil1;

import java.util.NoSuchElementException;

/**
 * Realisiert Häufigkeitstabellen für Wörter als linear-verkettete Liste
 * Die Worte werden nach absteigender Häufigkeit sortiert
 * @author oliverbittel
 * @author m.biselli
 * @since 04.03.2021
 */
public class LinkedListFrequencyTable<T> extends AbstractFrequencyTable<T> {
    //private Instanzvariable; gibt Zahl der Elemente an
    private int size = 0;
    //Feld aus Wort-Häufgikeit-Paaren | geordnet nach absteigender Häufigket
    private Node begin;
    private Node end;


    private class Node {  //??non-static??
        private Element<T> data;
        private Node next;
        private Node prev;

        public Node(Element<T> data, Node next, Node prev) {
            this.next = next;
            this.prev = prev;
            this.data = data;
        }
    }

    public LinkedListFrequencyTable() {
        clear();
    }

    @Override
    public int size() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return size;
    }

    @Override
    public final void clear() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        begin = new Node(null, null, null);  // [begin] -> [data: null| next: null| prev: null]
        end = new Node(null, null, begin);        // [end]   -> [data: null| next: null| prev: begin]
        begin.next = end;                                   // [begin] -> [data: null| next: end | prev: null]
        size = 0;
    }

    @Override
    public void add(T data, int f) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (data == null || data.equals("") || f <= 0) {
            throw new IllegalArgumentException();
        }
        for (Node p = begin.next; p.next != null; p = p.next) { // Start: begin bis max.: end mit end.next == null
            if (p.data.getData().equals(data)) {   // Falls Wort mit gleichem String gefunden wird:
                p.data.addFrequency(f);         // addFrequency(int f)
                moveToLeft(p);                  // Einrücken, um Sortierung zu erhalten
                return;
            }
        }
        //Ist das Wort noch nicht vorhanden, wird es als neuer Eintrag hinzugefügt
        end.prev.next = new Node(new Element<T>(data, f), end, end.prev);
        end.prev = end.prev.next;
        //In diesem Fall muss die Größe angepasst werden
        this.size++;
        //Nach links einrücken
        moveToLeft(end.prev);
    }

    @Override
    public void add(T data) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.add(data, 1);
    }

    @Override
    public Element<T> get(int pos) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (size() == 0 || pos < 0 || pos > this.size() - 1) {
            throw new NoSuchElementException();
        }
        // lokale Hilfsvariable
        Node p;
        // Wird auf Node an der Stelle pos gesetzt
        if (pos <= size()/2) {  // Abfrage
            p = begin.next;
            for (int i = 0; i < pos; i++) { // pos Schritte nach rechts gehen, da Start auf begin.next
                p = p.next;                 // p schrittweise auf gesuchtes Element setzen
            }
        } else {
            p = end.prev;
            for (int i = size(); i > pos + 1; i--) { // (size - 1) - pos Schritte nach links gehen
                p = p.prev;                          // p schrittweise auf gesuchtes Element setzen
            }
        }
        return p.data;
    }

    @Override
    public int get(T data) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (data == null || data.equals("")) {
            throw new IllegalArgumentException();
        }
        for (Node p = begin.next; p.next.next != null; p = p.next) {
            if (p.next.data.getData().equals(data)) {
                return p.next.data.getFrequency();
            }
        }
        return 0;
    }

    private void moveToLeft(Node p) {
            //Aushängen von p an alter Stelle
            p.prev.next = p.next;
            p.next.prev = p.prev;

            while (p.prev.prev != null && p.prev.data.getFrequency() < p.data.getFrequency()) {
                p.prev = p.prev.prev;
                p.next = p.prev.next;
            }

            //Einhängen von p an neuer Stelle
            p.prev.next = p;
            p.next.prev = p;
    }
}
