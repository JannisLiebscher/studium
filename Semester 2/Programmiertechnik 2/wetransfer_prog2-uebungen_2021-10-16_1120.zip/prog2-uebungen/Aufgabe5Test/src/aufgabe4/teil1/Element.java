package aufgabe4.teil1;

/**
 * Klasse fÃ¼r WÃ¶rter mit ihren HÃ¤ufigkeiten.
 * @author oliverbittel
 * @since 22.3.2019
 */
public class Element<T> {
    final private T data;
    private int frequency;

    /**
     * Konstruktor.
     * @param e Element
     * @param f H&auml;ufgkeit
     */
    public Element(T e, int f) {
        this.data = e;
        this.frequency = f;
    }

    /**
     * Liefert Element zur&uuml;ck.
     * @return Element
     */
    public T getData() {
        return this.data;
    }

    /**
     * Liefert H&auml;ufgkeit zur&uuml;ck.
     * @return H&auml;ufgkeit
     */
    public int getFrequency() {
        return frequency;
    }

    /**
     * Addiert zur H&auml;ufgkeit f dazu.
     * @param f H&auml;ufgkeits&auml;nderung.
     */
    public void addFrequency(int f) {
        frequency += f;
    }

    /**
     * Liefert eine String-Darstellung zur&uuml;ck.
     * @return String-Darstellung.
     */
    @Override
    public String toString() {
        return data + ":" + frequency;
    }
}
