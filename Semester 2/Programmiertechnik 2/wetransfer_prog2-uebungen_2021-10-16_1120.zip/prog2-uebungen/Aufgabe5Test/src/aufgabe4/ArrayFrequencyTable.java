package aufgabe4;

import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Realisiert Häufigkeitstabellen für Wörter als Feld
 * Die Worte werden nach absteigender Häufigkeit sortiert
 * @author oliverbittel
 * @author m.biselli
 * @since 04.03.2021
 */
public class ArrayFrequencyTable<T> extends AbstractFrequencyTable<T> {
    //private Instanzvariable; gibt Zahl der Elemente an
    private int size = 0;
    private int modCount = 0;
    //Feld aus Wort-Häufgikeit-Paaren | geordnet nach absteigender Häufigket
    private Element<T>[] fqTable;
    //Standard- und Startgröße neu angelegter Tabellen
    private final int DEFAULT_SIZE = 100;

    public ArrayFrequencyTable() {
        clear();
    }

    @Override
    public Iterator<Element<T>> iterator() {
        return new ArrayListIterator();
    }

    private class ArrayListIterator implements Iterator<Element<T>> {
        private int current = -1;
        private final int expectedMod = modCount;

        @Override
        public boolean hasNext() {
            return current != size() - 1;
        }

        @Override
        public Element<T> next() {
            if (expectedMod != modCount)
                throw new ConcurrentModificationException();
            if (!hasNext())
                throw new NoSuchElementException();
            ++current;
            return fqTable[current];
        }
    }

    @Override
    public int size() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return this.size;
    }

    @Override
    @SuppressWarnings("unchecked")
    public final void clear() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.size = 0;
        modCount++;
        this.fqTable = (Element<T>[]) new Element[DEFAULT_SIZE];
    }

    @Override
    public void add(T e, int f) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (e == null || f <= 0) {
            throw new IllegalArgumentException();
        }

        for (int i = 0; i < this.size(); i++) {         //Läuft von links über this
            if (this.fqTable[i].getData().equals(e)) {  //Sucht, ob das gegebene Wort schon in der Liste vorhanden ist
                this.fqTable[i].addFrequency(f);        //falls ja, fügt es die mitgegebene Häufigkeit zu diesem hinzu.
                //if (i != 0 &&                           //Ist Wort-Häufigkeit größer als sein linker Nachbar, so wird
                //        this.fqTable[i].getFrequency() > this.fqTable[i - 1].getFrequency()) //es neu eingerückt
                this.moveToLeft(i);
                modCount++;
                return;
            }
        }
        //Ist die Liste voll, wird ein neues Feld mit gleichem Inhalt aber doppelter Größe erstellt
        if (this.size() == this.fqTable.length) {
            this.fqTable = Arrays.copyOf(this.fqTable, 2*this.size());
        }

        //Ist das Wort noch nicht vorhanden, wird es als neuer Eintrag hinzugefügt
        this.fqTable[this.size()] = new Element<T>(e, f);
        if (this.size() > 0) {
            this.moveToLeft(this.size());
        }
        //In diesem Fall muss die Größe angepasst werden
        this.size++;
        modCount++;
    }

    @Override
    public void add(T e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.add(e, 1);
    }

    @Override
    public Element<T> get(int pos) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if (pos < 0 || pos > this.size() - 1) {
            throw new IllegalArgumentException();
        }
        return this.fqTable[pos];
    }

    @Override
    public int get(T data) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        for (int i = 0; i < this.size(); i++) {
            if (this.fqTable[i].getData().equals(data)) {
                return this.fqTable[i].getFrequency();
            }
        }
        return 0;
    }

    private void moveToLeft(int pos) {
        //lokale Variable zum Speichern des zu verschiebenden Worts
        Element<T> e = this.fqTable[pos];

        //Laufvariable
        int i = pos - 1;                                                    //Solange die Häufigkeit der Wörter links
        while(i >= 0 && e.getFrequency() > this.fqTable[i].getFrequency()) {//von w geringer sind, läuft Schleife
             this.fqTable[i+1] = this.fqTable[i];                           //weiter und schiebt dabei die Elemente
             i--;                                                           //um je eins nach rechts
        }
        this.fqTable[i+1] = e;                                              //zuletzt wird w eingefügt
    }
}
