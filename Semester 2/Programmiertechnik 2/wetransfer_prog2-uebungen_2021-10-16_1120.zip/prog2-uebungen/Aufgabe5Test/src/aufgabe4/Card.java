package aufgabe4;

public abstract class Card{
    enum Rank {SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE}
    enum Suit {HEARTS, DIAMONDS, CLUBS, SPADES}
}
