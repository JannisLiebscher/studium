package aufgabe4;

/**
 * Implementiert Grundfunktionen einer Häufigkeitstabelle zur Häufigkeitsanalyse
 * Beliebige Elemente vom Typ T werden in der Klasse Element gekapselt.
 * Jedes Element enthält seinen Datenwert und eine Häufigkeit.
 * @author M.Biselli
 * @since 15.04.2021
 * @param <T> Typ, der gespeichert wird
 */
public abstract class AbstractFrequencyTable<T> implements FrequencyTable<T> {
    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public void add(T data) { add(data, 1); }

    @Override
    public void addAll(FrequencyTable<? extends T> fq) {
        if (fq != null) {
            /*for (int i = 0; i < fq.size(); i++) {
                this.add(fq.get(i).getData(),       //Element mit Daten und Häufigkeit aus fq nehmen und
                        fq.get(i).getFrequency()); //in this "AbstractFrequencyTable" speichern
            }*/
            for (Element<?> data : fq)
                this.add(/*???*/(T)/*???*/ data.getData(), data.getFrequency());
        }
    }

    @Override
    public void collectMostFrequent(FrequencyTable<? super T> fq) {
        //fq leeren, um Elemente aus this unverfälscht darin speichern zu können
        fq.clear();
        //lokale Variable most für höchste frequency
        int most = this.get(0).getFrequency();  //this.get(0), da absteigend sortiert

        /*for (int i = 0; i < this.size(); i++) {         //läuft von links über this
            if (this.get(i).getFrequency() == most) {   //sucht nach Elementen, die alle die Frequency des linkesten
                fq.add(this.get(i).getData(), most);    //Wortes besitzen und speichert sie in fq
            } else {
                return;                                 //Bricht ab, sobald Worte mit geringerer Häufigkeit auftreten
            }
        }*/
        for (Element<T> data : this) {
            if (data.getFrequency() == most)
                fq.add(data.getData(), data.getFrequency());
            else
                return;
        }
    }

    @Override
    public void collectLeastFrequent(FrequencyTable<? super T> fq) {
        //fq leeren, um Wörter aus this unverfälscht darin speichern zu können
        fq.clear();
        //lokale Variable leas für geringste frequency
        //int least = this.get(this.size()).getFrequency();//this.get(size), da absteigend sortiert

        /*for (int i = 0; i < this.size(); i++) {            //läuft von links über this
            //if (this.get(i).getFrequency() == least) {   //sucht nach Wörtern, die alle die Frequency 1
            //fq.add(this.get(i).getWord(), least);    //besitzen und speichert sie in fq
            if (this.get(i).getFrequency() == 1) {
                fq.add(this.get(i).getData());
            } /*else {
                return;                                    //Bricht ab, sobald Worte mit höherer Häufigkeit auftreten
            }*/
        //}
        for (Element<T> data : this) {
            //if (this.get(T).getFrequency() == least)
            if (data.getFrequency() == 1) fq.add(data.getData()/*,least*/);
            else return;
        }
    }

    /**
     * Liefert eine String-Darstellung zur&uuml;ck.
     * @return String-Darstellung.
     */
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        //lokale size-Variable
        int size = this.size();

        //  String bauen  //
        s.append("{");
        /*for (int i = 0; i < size; i++) {                    //läuft von links über alle Elemente in this
            s.append(this.get(i).toString()).append(", ");  //hängt String-Darstellung der Worte, die in Word.java
        }*/                                                   //definiert ist, an den StringBuilder an
        for (Element<T> data : this)
            s.append(data.toString()).append(", ");
        s.append("} size = ").append(size);

        return s.toString();
    }
}
