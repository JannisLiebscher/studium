package aufgabe4;

import java.util.Random;

public class RedCard extends Card {
    private final Suit suit;
    private final Rank rank;

    public RedCard(Suit s, Rank r) {
        if (!s.equals(Suit.HEARTS) && !s.equals(Suit.DIAMONDS))
            throw new IllegalArgumentException();
        suit = s;
        rank = r;
    }

    public RedCard() {
        Random rand = new Random();
        int r = rand.nextInt(8);

        switch (r) {
            case 0 -> rank = Rank.SEVEN;
            case 1 -> rank = Rank.EIGHT;
            case 2 -> rank = Rank.NINE;
            case 3 -> rank = Rank.TEN;
            case 4 -> rank = Rank.JACK;
            case 5 -> rank = Rank.QUEEN;
            case 6 -> rank = Rank.KING;
            case 7 -> rank = Rank.ACE;
            default -> throw new IllegalStateException("Unexpected value: " + r);
        }
        if (rand.nextInt() % 2 == 0) suit = Suit.HEARTS;
        else suit = Suit.DIAMONDS;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RedCard redCard = (RedCard) o;
        return suit == redCard.suit && rank == redCard.rank;
    }

    @Override
    public String toString() { return rank +" of "+ suit; };
}
