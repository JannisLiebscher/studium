package GenerischeSortiermethoden;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Arrays;

public class HybridesQuickSortTest {

    public static void main(String[] args) throws IOException {
        long start = System.nanoTime();

        Integer[] intArr = {2,1,6,7,3,5,1,2,6,9,11,0,8,4,4,7,2,3,6,1};
        HybridesQuickSort.quickSort(intArr);
        System.out.println(Arrays.toString(intArr));
        Integer[] intArr2 = {2,1,6,7,3,5,1,2,6,9,11,0,8,4,4,7,2,3,6,1};
        HybridesQuickSort3Median.quickSort(intArr2);
        System.out.println(Arrays.toString(intArr2));

        String[] strArr = {"Tim", "Schober", "Ayaz", "Hasan", "LOL"};
        HybridesQuickSort.quickSort(strArr);
        System.out.println(Arrays.toString(strArr));
        String[] strArr2 = {"Tim", "Schober", "Ayaz", "Hasan", "LOL"};
        HybridesQuickSort3Median.quickSort(strArr2);
        System.out.println(Arrays.toString(strArr2));

        long start2 = System.nanoTime();
        Integer[] randArray = randArr(10000, 1000000);
        HybridesQuickSort.quickSort(randArray);
        Arrays.sort(randArray);
        //System.out.println(Arrays.toString(randArray));
        long end2 = System.nanoTime();

        long start3 = System.nanoTime();
        Integer[] randArray2 = randArr(10000, 1000000);
        HybridesQuickSort3Median.quickSort(randArray2);
        //System.out.println(Arrays.toString(randArray2));
        long end3 = System.nanoTime();

        long end = System.nanoTime();
        double elapsedTime2 = (double)(end2 - start2)/1.0e06/1000;
        System.out.printf("QSTime: %.3f sekunden%n", elapsedTime2);
        double elapsedTime3 = (double)(end3 - start3)/1.0e06/1000;
        System.out.printf("QS3MTime: %.3f sekunden%n", elapsedTime3);

        text();

        double elapsedTime = (double)(end - start)/1.0e06/1000;
        System.out.printf("Total Time: %.3f sekunden%n", elapsedTime);
    }

    private static Integer[] randArr(int max, int length) {
        Integer[] array = new Integer[length];
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * max);
        }
        return array;
    }

    private static void text() throws IOException {
        long start = System.nanoTime();

        ArrayList<String> s = new ArrayList<>();
        LineNumberReader in;
        in = new LineNumberReader(new FileReader("Kafka_Der_Prozess.txt"));
        String line;
        while ((line = in.readLine()) != null) {
            String[] wf = line.split("[^a-z^A-Z^ÃŸ^Ã¤^Ã¶^Ã¼^Ã„^Ã–^Ãœ]+");
            for (String w: wf) {
                if (w.length() == 0 || w.length() == 1)
                    continue;
                s.add(w);
            }
        }
        String[] l = s.toArray(new String[]{});
        HybridesQuickSort.quickSort(l);

        long end = System.nanoTime();
        double elapsedTime = (double)(end-start)/1.0e06/1000;
        System.out.printf("Text Time: %.3f sekunden%n", elapsedTime);
        //System.out.println(Arrays.toString(l));
    }
}