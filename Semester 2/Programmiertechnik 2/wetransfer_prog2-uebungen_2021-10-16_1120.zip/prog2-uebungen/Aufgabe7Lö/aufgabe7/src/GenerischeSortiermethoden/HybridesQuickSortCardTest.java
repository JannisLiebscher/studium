package GenerischeSortiermethoden;

import java.util.ArrayList;
import java.util.Arrays;

public class HybridesQuickSortCardTest {

   public static void main(String[] args) {
       int Max = 0;
       long totalstart = System.nanoTime();
       //sortiert wird die Farbe nach: Herz > Karo > Piq > Kreuz
       //sortiert wird der Rang nach: Ass > Koenig > Dame > Bube > Zehn > Neun > Acht > Sieben
       for (int j = 0; j <= 1; j++) {
           Max += 100000;

           ArrayList<Card> unsorted = new ArrayList<>();
           for (int i = 0; i < Max; i++) {
               if (Math.random() < 0.5) {
                   Card card = new RedCard();
                   unsorted.add(card);
               } else {
                   Card card = new BlackCard();
                   unsorted.add(card);
               }
           }

           //Quicksort:
           Card[] qsarray = unsorted.toArray(new Card[]{});
           long qsstart = System.nanoTime();
           HybridesQuickSort.quickSort(qsarray);
           long qsend = System.nanoTime();
           HybridesQuickSort.quickSort(qsarray);
           long qssortedend = System.nanoTime();
           //System.out.println(Arrays.toString(qsarray));

           //Quicksort3Median:
           Card[] qs3marray = unsorted.toArray(new Card[]{});
           long qs3mstart = System.nanoTime();
           HybridesQuickSort3Median.quickSort(qs3marray);
           long qs3mend = System.nanoTime();
           HybridesQuickSort3Median.quickSort(qs3marray);
           long qs3msortedend = System.nanoTime();
           //System.out.println(Arrays.toString(qs3marray));

           //Arraysort
           Card[] array = unsorted.toArray(new Card[]{});
           long arraystart = System.nanoTime();
           Arrays.sort(array);
           long arrayend = System.nanoTime();
           Arrays.sort(array);
           long arraysortedend = System.nanoTime();
           //System.out.println(Arrays.toString(array));

           double elapsedTimeQs = (double) (qsend - qsstart) / 1.0e06 / 1000;
           double elapsedTimeQssorted = (double)(qssortedend-qsend)/1.0e06/1000;
           double elapsedTimeQs3m = (double) (qs3mend - qs3mstart) / 1.0e06 / 1000;
           double elapsedTimeQs3msorted = (double) (qs3msortedend - qs3mend) / 1.0e06 / 1000;
           double elapsedTimeArray = (double) (arrayend - arraystart) / 1.0e06 / 1000;
           double elapsedTimeArraysorted = (double) (arraysortedend - arrayend) / 1.0e06 / 1000;

           System.out.printf("QS               Anzahl: %d Time: %.3f sekunden%n", Max, elapsedTimeQs);
           System.out.printf("QS sorted        Anzahl: %d Time: %.3f sekunden%n", Max, elapsedTimeQssorted);
           System.out.printf("QS3M             Anzahl: %d Time: %.3f sekunden%n", Max, elapsedTimeQs3m);
           System.out.printf("QS3M sorted      Anzahl: %d Time: %.3f sekunden%n", Max, elapsedTimeQs3msorted);
           System.out.printf("ArraySort        Anzahl: %d Time: %.3f sekunden%n", Max, elapsedTimeArray);
           System.out.printf("ArraySort sorted Anzahl: %d Time: %.3f sekunden%n", Max, elapsedTimeArraysorted);
       }
       long totalend = System.nanoTime();
       double elapsedTimeTotal = (double)(totalend-totalstart)/1.0e06/1000;
       System.out.printf("Total Time: %.3f sekunden%n", elapsedTimeTotal);
   }

}
