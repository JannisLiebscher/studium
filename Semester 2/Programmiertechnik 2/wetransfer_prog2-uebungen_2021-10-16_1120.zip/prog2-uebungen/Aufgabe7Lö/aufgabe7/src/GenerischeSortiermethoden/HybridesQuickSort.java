package GenerischeSortiermethoden;

public class HybridesQuickSort {

    private static final int N = 100;//ab groeße wird mit insertionSort sortiert

    public static <T extends Comparable<T>> void quickSort(T[] a) {
        quickSort(a, 0, a.length - 1);
    }

    public static <T extends Comparable<T>> void quickSort(T[] a, int li, int re) {
        while (re > li) {
            if ((re - li) <= N) {
                insertionSort(a, li, re);
                break;
            } else {
                int i = partition(a, li, re);
                if (i-li < re-i) {
                    quickSort(a, li, i-1);
                    li = i + 1;
                } else {
                    quickSort(a, i+1, re);
                    re = i - 1;
                }
            }
        }
    }

    public static <T extends Comparable<T>> int partition(T[] a, int li, int re) {
        T v = a[re]; // Pivotelement
        int i = li-1;
        int j = re;
        while (true) {
            do i++; while (a[i].compareTo(v) < 0);//Werte vergleichen; vorher: a[i] < v
            do j--; while (j >= li && a[j].compareTo(v) > 0);//Werte vergleichen; vorher: a[j] > v
            if (i >= j)
                break;
            swap(a, i, j);
        }
        a[re] = a[i];
        a[i] = v;
        return i;
    }

    public static <T> void swap(T[] a, int i, int j) {
        T t = a[i];
        a[i] = a[j];
        a[j] = t;
    }

    public static <T extends Comparable<T>> void insertionSort(T[] a, int li, int re) {
        for (int i = li; i < re + 1; i++) {
            T v = a[i];
            int j = i - 1;
            while (j >= 0 && a[j].compareTo(v) > 0) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = v;
        }
    }
}
