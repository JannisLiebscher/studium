package Haeufigkeitsanalyse;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;

public class Person {
    private final String vorname;
    private final String nachname;
    private final LocalDate gebDatum;

    private Person(String v,String n,LocalDate date) {
        this.vorname = v;
        this.nachname = n;
        this.gebDatum = date;
    }

    private String getName() {
        return this.vorname + " " + this.nachname;
    }

    private LocalDate getGeburtsdatum() {
        return this.gebDatum;
    }

    @Override
    public String toString() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return this.vorname + " " + this.nachname + " wurde am " + dtf.format(this.getGeburtsdatum()) + " geboren";
    }

    public static void main(String[] args) {
        List<Person> PersList = new LinkedList<>();
        Person tim = new Person("Tim", "Schober", LocalDate.of(2000, 11, 16));
        Person ben = new Person("Ben", "Schober", LocalDate.of(2004, 4, 14));
        Person janis = new Person("Janis", "Vötsch", LocalDate.of(2001, 5, 31));
        Person adrian = new Person("Adrian", "Ott", LocalDate.of(2000, 9, 29));
        Person annika = new Person("Annika", "Ederer", LocalDate.of(2000, 9, 28));
        Person dennis = new Person("Dennis", "Rudik", LocalDate.of(2001, 7, 1));
        Person thomas = new Person("Thomas", "Schober", LocalDate.of(1968, 10, 8));
        Person alexandra = new Person("Alexandra", "Schober", LocalDate.of(1968, 12, 19));
        PersList.add(tim);
        PersList.add(ben);
        PersList.add(janis);
        PersList.add(adrian);
        PersList.add(annika);
        PersList.add(dennis);
        PersList.add(thomas);
        PersList.add(alexandra);

        LocalDate ago = LocalDate.now().minusYears(18);
        Predicate<Person> istVolljaehrig = x -> x.getGeburtsdatum().compareTo(ago) < 0;

        for (Person x : PersList) {
            if (istVolljaehrig.test(x)) {
                System.out.println(x.getName() + " ist volljährig");
            } else {
                System.out.println(x.getName() + " ist nicht volljährig");
            }
        }
        System.out.println();

        Comparator<Person> cmp = Comparator.comparing(Person::getGeburtsdatum);//(x, y) -> x.getGeburtsdatum().compareTo(y.getGeburtsdatum())
        Collections.sort(PersList, cmp);
        for (Person x : PersList) {
            System.out.println(x.toString());
        }
        System.out.println();

        Collections.sort(PersList, cmp.reversed());
        for (Person x : PersList) {
            System.out.println(x.toString());
        }
        System.out.println();

        PersList.stream()
                .filter(istVolljaehrig)
                .sorted(cmp.reversed())//keine Ahnung was in chronologisch aufsteigender Reihenfolge heißt reversed() kann für umgekehrter Reihenfolge weggelassen werden
                .forEach(x-> System.out.println(x.getGeburtsdatum()));
        System.out.println();

        Predicate<Person> ersterBuchstabeistA = x-> x.getName().charAt(0) == 'A' || x.getName().charAt(0) == 'a';
        PersList.stream()
                .filter(ersterBuchstabeistA)
                .sorted(cmp)
                .limit(3)
                .forEach(x-> System.out.println(x.toString()));
    }
}
