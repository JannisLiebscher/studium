package Aufgabe9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class Level3CalcCheckBox extends JPanel {
    private String winkelmass = "deg";
    public String getRadOrDeg() {
        return winkelmass;
    }
    Level4CalcText txt;

    public Level3CalcCheckBox() {
        this.setBackground(Color.gray);
        txt = new Level4CalcText();
        JPanel checkboxPanel = new JPanel();
        checkboxPanel.setLayout(new GridLayout(1,3));
        JPanel Level3 = new JPanel();
        Level3.setLayout(new GridLayout(2,1));
        //----------------------------------------------------------------------------------- Winkelmass RadioButtons
        JRadioButton deg = new JRadioButton("Deg");
        deg.setSelected(true);
        JRadioButton rad = new JRadioButton("Rad");
        ButtonGroup group = new ButtonGroup();
        group.add(deg);
        group.add(rad);
        deg.setBackground(Color.gray);
        rad.setBackground(Color.gray);

        deg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                winkelmass = "deg";
            }
        });
        rad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                winkelmass = "rad";
            }
        });
        //----------------------------------------------------------------------------------- Display Checkbox
        JCheckBox display = new JCheckBox("Helles Display");
        display.setSelected(true);
        display.setBackground(Color.gray);
        display.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(display.isSelected()) {
                    txt.setLight();

                } else {
                    txt.setDark();
                }
            }
        });
        //----------------------------------------------------------------------------------- Zusammenfügen
        checkboxPanel.add(deg);
        checkboxPanel.add(rad);
        checkboxPanel.add(display);
        checkboxPanel.setBackground(Color.gray);
        Level3.add(txt);
        Level3.add(checkboxPanel);
        Level3.setBackground(Color.gray);
        this.add(Level3);
        this.setVisible(true);
    }
}