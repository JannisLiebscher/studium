package Aufgabe9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Level1CalcClear extends JPanel implements ActionListener {
    Level2CalcButtons button;
    JButton clear;

    public Level1CalcClear() {
        this.setBackground(Color.gray);
        button = new Level2CalcButtons();
        JPanel cl = new JPanel();
        JPanel Level1 = new JPanel();
        Level1.setLayout(new GridLayout(2,1));
        Level1.setBackground(Color.gray);
        clear = new JButton("clear");
        clear.addActionListener(this);

        cl.add(clear);
        cl.setBackground(Color.gray);
        //----------------------------------------------------------------------------------- Zusammenfügen
        Level1.add(button);
        Level1.add(cl);
        this.add(Level1);
        this.setVisible(true);



    }

    @Override
    public void actionPerformed(ActionEvent e) {
        button.check.txt.setOPY(0);
        button.check.txt.setOPX(0);
        button.check.txt.setRES(0);
    }
}
