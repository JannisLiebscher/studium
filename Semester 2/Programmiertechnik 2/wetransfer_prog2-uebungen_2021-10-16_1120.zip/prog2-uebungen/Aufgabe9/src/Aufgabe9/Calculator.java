package Aufgabe9;
import javax.sql.rowset.JdbcRowSet;
import javax.swing.*;
import java.awt.*;


public class Calculator extends JFrame {
    private Calculator(){
        this.setBackground(Color.gray);
        this.setTitle("Taschenrechner");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(420, 420);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        Level1CalcClear c = new Level1CalcClear();
        this.add(c);
        this.setVisible(true);
    }
    public static void main(String[] args){
        new Calculator();
    }
}
