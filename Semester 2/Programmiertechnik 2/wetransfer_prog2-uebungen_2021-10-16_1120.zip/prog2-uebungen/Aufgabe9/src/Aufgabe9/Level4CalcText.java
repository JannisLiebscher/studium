package Aufgabe9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Level4CalcText extends JPanel  {

    private JTextField opx;
    private JTextField opy;
    private JTextField res;

    //----------------------------------------------------------------------------------- Textfeldmethoden
    public void setDark() {
        opx.setBackground(Color.black);
        opx.setForeground(Color.yellow);
        opy.setBackground(Color.black);
        opy.setForeground(Color.yellow);
        res.setBackground(Color.black);
        res.setForeground(Color.yellow);
    }

    public void setLight() {
        opx.setBackground(Color.white);
        opx.setForeground(Color.black);
        opy.setBackground(Color.white);
        opy.setForeground(Color.black);
        res.setBackground(Color.white);
        res.setForeground(Color.black);
    }

    public double getOPX() {
        if (isNumeric(opx.getText())) {
            return Double.parseDouble(opx.getText());
        }
        opx.setForeground(Color.red);
        return 0;
    }
    public double getOPY() {
        if (isNumeric(opy.getText())) {
            return Double.parseDouble(opy.getText());
        }
        opy.setForeground(Color.red);
        return 0;
    }
    public void setRES(double n) {
        res.setText(Double.toString(n));
    }
    public void setOPX(double n) {
        opx.setText(Double.toString(n));
    }
    public void setOPY(double n) {
        opy.setText(Double.toString(n));
    }
    //-----------------------------------------------------------------------------------
    public Level4CalcText() {

        this.setBackground(Color.gray);
        JLabel op1Label = new JLabel("Operand x");
        JLabel op2Label = new JLabel("Operand y");
        JLabel resLabel = new JLabel("Resultat");
        //----------------------------------------------------------------------------------- Operand x
        opx = new JTextField("",10);
        opx.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (opx.getBackground().equals(Color.black)) {
                    opx.setForeground(Color.yellow);
                } else {
                    opx.setForeground(Color.black);
                }
            }
            @Override
            public void keyPressed(KeyEvent e) { }
            @Override
            public void keyReleased(KeyEvent e) { }
        });
        //----------------------------------------------------------------------------------- Operand y
        opy = new JTextField("",10);
        opy.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (opy.getBackground().equals(Color.black)) {
                    opy.setForeground(Color.yellow);
                } else {
                    opy.setForeground(Color.black);
                }
            }
            @Override
            public void keyPressed(KeyEvent e) { }
            @Override
            public void keyReleased(KeyEvent e) { }
        });
        //----------------------------------------------------------------------------------- Ergebnis Feld
        res = new JTextField("",10);
        res.setEditable(false);
        //----------------------------------------------------------------------------------- txt Panel
        JPanel paneltxt = new JPanel();
        paneltxt.setLayout(new GridLayout(3,2));
        paneltxt.add(op1Label);
        paneltxt.add(opx);
        paneltxt.add(op2Label);
        paneltxt.add(opy);
        paneltxt.add(resLabel);
        paneltxt.add(res);
        paneltxt.setBackground(Color.gray);

        this.add(paneltxt);
        this.setVisible(true);
    }

    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch(NumberFormatException e){
            System.out.println("Keine Gültige Zahl!");
            return false;
        }
    }
}
