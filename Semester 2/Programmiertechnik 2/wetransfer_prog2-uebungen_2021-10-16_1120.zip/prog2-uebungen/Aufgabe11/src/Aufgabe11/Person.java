package Aufgabe11;

/*
 * Person
 * Tobias Latt; 21.06.2021
 */

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;

public class Person {
    private final String vorname;
    private final String nachname;
    private final LocalDate gebDatum;

    private Person(String v,String n,LocalDate date) {
        this.vorname = v;
        this.nachname = n;
        this.gebDatum = date;
    }

    private String getName() {
        return this.vorname + " " + this.nachname;
    }

    private LocalDate getGeburtsdatum() {
        return this.gebDatum;
    }

    @Override
    public String toString() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return this.vorname + " " + this.nachname + " wurde am " + dtf.format(this.getGeburtsdatum()) + " geboren.";
    }

    public static void main(String[] args) {
        List<Person> PersList = new LinkedList<>();
        Person manuel = new Person("Manuel", "Neuer", LocalDate.of(1989, 12, 11));
        Person albert = new Person("Albert", "Arbeitsloser", LocalDate.of(2011, 5, 23));
        Person fixi = new Person("Fixi", "Hartman", LocalDate.of(1969, 6, 6));
        Person hurry = new Person("Hurry", "Cane", LocalDate.of(2020, 9, 29));
        Person thai = new Person("Thai", "Fuhn", LocalDate.of(2001, 12, 29));
        Person somting = new Person("Somting", "Wong", LocalDate.of(2001, 10, 1));
        Person wetu = new Person("Wetu", "lo", LocalDate.of(2001, 9, 8));
        Person bing = new Person("Bing", "Bangbong", LocalDate.of(2001, 8, 19));
        Person albrecht = new Person("Albrecht", "Maier", LocalDate.of(1954, 10, 15));
        PersList.add(manuel);
        PersList.add(albert);
        PersList.add(fixi);
        PersList.add(hurry);
        PersList.add(thai);
        PersList.add(somting);
        PersList.add(wetu);
        PersList.add(bing);
        PersList.add(albrecht);


        // Volljährigkeit Überprüfen
        LocalDate ago = LocalDate.now().minusYears(18);
        Predicate<Person> istVolljaehrig = x -> x.getGeburtsdatum().compareTo(ago) < 0;

        for (Person x : PersList) {
            if (istVolljaehrig.test(x)) {
                System.out.println(x.getName() + " ist volljährig!");
            } else {
                System.out.println(x.getName() + " ist minderjährig!");
            }
        }
        System.out.println();

        // Geburtsdatum in aufsteigender Reihenfolge sortiert
        Comparator<Person> cmp = Comparator.comparing(Person::getGeburtsdatum);
        Collections.sort(PersList, cmp);
        for (Person x : PersList) {
            System.out.println(x);
        }
        System.out.println();

        // Geburtsdatum in absteigender Reihenfolge sortiert
        Collections.sort(PersList, cmp.reversed());
        for (Person x : PersList){
            System.out.println(x);
        }
        System.out.println();

        // Stream zum ausgeben aller volljährigen Personen in chronologisch aufsteigender Reihenfolge
        PersList.stream()
                .filter(istVolljaehrig)
                .sorted(cmp.reversed())
                .forEach(x -> System.out.println(x.getGeburtsdatum()));

        System.out.println();

        // Stream zum ausgeben der ältesten 3 Personen mit Anfgangsbuchstaben "A"
        Predicate<Person> firstLetterA = x -> x.getName().charAt(0) == 'A' || x.getName().charAt(0) == 'a';
        PersList.stream()
                .filter(firstLetterA)
                .sorted(cmp)
                .limit(3)
                .forEach(System.out::println);
    }
}
