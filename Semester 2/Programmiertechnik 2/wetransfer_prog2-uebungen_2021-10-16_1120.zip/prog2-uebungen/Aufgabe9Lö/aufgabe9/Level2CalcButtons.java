package aufgabe9;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Level2CalcButtons extends JPanel implements ActionListener {
    Level3CalcCheckBox check;
    JButton sum;
    JButton product;
    JButton difference;
    JButton quotient;
    JButton sin;
    JButton cos;
    JButton power;
    JButton log2;

    public Level2CalcButtons() {
        this.setBackground(Color.gray);
        check = new Level3CalcCheckBox();
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2,4));
        JPanel Level2 = new JPanel();
        Level2.setLayout(new GridLayout(2,1));
        //----------------------------------------------------------------------------------- Buttons
        sum = new JButton("+");
        sum.addActionListener(this);
        product = new JButton("*");
        product.addActionListener(this);
        difference = new JButton("-");
        difference.addActionListener(this);
        quotient = new JButton("/");
        quotient.addActionListener(this);
        sin = new JButton("sin");
        sin.addActionListener(this);
        cos = new JButton("cos");
        cos.addActionListener(this);
        power = new JButton("x^y");
        power.addActionListener(this);
        log2 = new JButton("log2");
        log2.addActionListener(this);
        //----------------------------------------------------------------------------------- Buttons in ButtonPanel
        buttonPanel.add(sum);
        buttonPanel.add(product);
        buttonPanel.add(difference);
        buttonPanel.add(quotient);
        buttonPanel.add(sin);
        buttonPanel.add(cos);
        buttonPanel.add(power);
        buttonPanel.add(log2);
        buttonPanel.setBackground(Color.gray);
        //----------------------------------------------------------------------------------- Zusammenfügen
        Level2.add(check);
        Level2.add(buttonPanel);
        Level2.setBackground(Color.gray);
        this.add(Level2);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        double result;
        //----------------------------------------------------------------------------------- Summe
        if (source == sum) {
            result = check.txt.getOPX() + check.txt.getOPY();
            check.txt.setRES(result);
        //----------------------------------------------------------------------------------- Produkt
        } else if (source == product) {
            result = check.txt.getOPX() * check.txt.getOPY();
            check.txt.setRES(result);
        //----------------------------------------------------------------------------------- Differenz
        } else if (source == difference) {
            result = check.txt.getOPX() - check.txt.getOPY();
            check.txt.setRES(result);
        //----------------------------------------------------------------------------------- Quotient
        } else if (source == quotient) {
            result = check.txt.getOPX() / check.txt.getOPY();
            check.txt.setRES(new BigDecimal(result).setScale(5, RoundingMode.HALF_UP).doubleValue());
        //----------------------------------------------------------------------------------- Sinus
        } else if (source == sin) {
            if (check.getRadOrDeg().equals("deg")) {
                result = Math.sin(Math.toRadians(check.txt.getOPX()));
            } else {
                result = Math.sin(check.txt.getOPX());
            }
            check.txt.setOPY(0);
            check.txt.setRES(new BigDecimal(result).setScale(5, RoundingMode.HALF_UP).doubleValue());
        //----------------------------------------------------------------------------------- Cosinus
        } else if (source == cos) {
            if (check.getRadOrDeg().equals("deg")) {
                result = Math.cos(Math.toRadians(check.txt.getOPX()));
            } else {
                result = Math.cos(check.txt.getOPX());
            }
            check.txt.setOPY(0);
            check.txt.setRES(new BigDecimal(result).setScale(5, RoundingMode.HALF_UP).doubleValue());
        //----------------------------------------------------------------------------------- Potenz
        } else if (source == power) {
            result = Math.pow(check.txt.getOPX(), check.txt.getOPY());
            check.txt.setRES(new BigDecimal(result).setScale(5, RoundingMode.HALF_UP).doubleValue());
        //----------------------------------------------------------------------------------- Log2
        } else if (source == log2) {
            result = Math.log(check.txt.getOPX()) / Math.log(2);
            check.txt.setOPY(0);
            check.txt.setRES(new BigDecimal(result).setScale(5, RoundingMode.HALF_UP).doubleValue());
        }
    }
}
