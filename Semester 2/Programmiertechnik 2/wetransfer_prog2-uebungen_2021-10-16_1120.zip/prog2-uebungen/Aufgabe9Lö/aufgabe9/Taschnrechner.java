package aufgabe9;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

public class Taschnrechner extends JFrame {

    private JPanel contentPane;
    private JTextField JTextFieldErgebniss;
    private JButton JButtonEins;
    private JButton JButtonZwei;
    private JButton JbuttonDrei;
    private JButton JButtonVier;
    private JButton JButtonFünf;
    private JButton JButtonSechs;
    private JButton JButtonSieben;
    private JButton JButtonAcht;
    private JButton btnNewButton;
    private JButton JButtonNull;
    private JLabel JLaberlOperand;
    private JTextField JTextFieldOperand;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Taschnrechner frame = new Taschnrechner();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     *
     */
    String operator = "o";
    double erg;
    double op;
    double zerg;
    private JButton JButtonPlus;
    private JButton JButtonMinus;
    private JButton JButtonIstGleich;
    private JButton JButtonMal;

    public Taschnrechner() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(Color.DARK_GRAY);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel JLabelErgebniss = new JLabel("Ergebniss");
        JLabelErgebniss.setBackground(Color.BLACK);
        JLabelErgebniss.setForeground(Color.RED);
        JLabelErgebniss.setBounds(345, 200, 59, 20);
        contentPane.add(JLabelErgebniss);

        JTextFieldErgebniss = new JTextField();
        JTextFieldErgebniss.setBackground(Color.WHITE);
        JTextFieldErgebniss.setBounds(338, 231, 86, 20);
        contentPane.add(JTextFieldErgebniss);
        JTextFieldErgebniss.setColumns(10);

        JButtonEins = new JButton("1");										//Button 0-9
        JButtonEins.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+1;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonEins.setBounds(10, 133, 89, 23);
        contentPane.add(JButtonEins);

        JButtonZwei = new JButton("2");
        JButtonZwei.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+2;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonZwei.setBounds(103, 133, 89, 23);
        contentPane.add(JButtonZwei);

        JbuttonDrei = new JButton("3");
        JbuttonDrei.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+3;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JbuttonDrei.setBounds(197, 133, 89, 23);
        contentPane.add(JbuttonDrei);

        JButtonVier = new JButton("4");
        JButtonVier.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+4;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonVier.setBounds(10, 156, 89, 23);
        contentPane.add(JButtonVier);

        JButtonFünf = new JButton("5");
        JButtonFünf.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+5;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonFünf.setBounds(103, 156, 89, 23);
        contentPane.add(JButtonFünf);

        JButtonSechs = new JButton("6");
        JButtonSechs.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+6;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonSechs.setBounds(197, 156, 89, 23);
        contentPane.add(JButtonSechs);

        JButtonSieben = new JButton("7");
        JButtonSieben.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+7;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonSieben.setBounds(10, 177, 89, 23);
        contentPane.add(JButtonSieben);

        JButtonAcht = new JButton("8");
        JButtonAcht.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10+8;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonAcht.setBounds(103, 177, 89, 23);
        contentPane.add(JButtonAcht);

        btnNewButton = new JButton("9");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op+10+9;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        btnNewButton.setBounds(197, 177, 89, 23);
        contentPane.add(btnNewButton);

        JButtonNull = new JButton("0");
        JButtonNull.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                op=op*10;
                JTextFieldOperand.setText(String.valueOf(op));
            }
        });
        JButtonNull.setBounds(10, 200, 89, 23);
        contentPane.add(JButtonNull);									//Button Ende

        JLaberlOperand = new JLabel("Operand");
        JLaberlOperand.setBounds(129, 11, 95, 14);
        contentPane.add(JLaberlOperand);

        JTextFieldOperand = new JTextField();
        JTextFieldOperand.setBounds(117, 35, 122, 20);
        contentPane.add(JTextFieldOperand);
        JTextFieldOperand.setColumns(10);

        JButtonPlus = new JButton("+");
        JButtonPlus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zerg=op;
                op=0;
                JTextFieldOperand.setText(String.valueOf(0));
                operator="d";


            }
        });
        JButtonPlus.setBounds(315, 66, 89, 23);
        contentPane.add(JButtonPlus);

        JButtonMinus = new JButton("-");
        JButtonMinus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zerg=op;
                op=0;
                JTextFieldOperand.setText(String.valueOf(op));
                operator="b";
            }
        });
        JButtonMinus.setBounds(315, 96, 89, 23);
        contentPane.add(JButtonMinus);

        JButtonIstGleich = new JButton("=");								//1=PLus;2=Minus;3=Geteilt;4=Mal//
        JButtonIstGleich.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if(operator.equals(1)){
                    erg=zerg+op;}
                if(operator.equals(2)){
                    erg=zerg-op;}
                if(operator.equals(3)){
                    erg=zerg/op;}
                if(operator.equals(4)){
                    erg=zerg*op;}




                JTextFieldErgebniss.setText(String.valueOf(erg));
            }
        });
        JButtonIstGleich.setBounds(242, 230, 89, 23);
        contentPane.add(JButtonIstGleich);

        JButton JButtonGeteilt = new JButton("/");
        JButtonGeteilt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                zerg=op;
                op=0;
                operator="c";
            }
        });
        JButtonGeteilt.setBounds(315, 130, 89, 23);
        contentPane.add(JButtonGeteilt);

        JButtonMal = new JButton("*");
        JButtonMal.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zerg=op;
                op=0;
                operator="d";
            }
        });
        JButtonMal.setBounds(315, 166, 89, 23);
        contentPane.add(JButtonMal);
    }
}
