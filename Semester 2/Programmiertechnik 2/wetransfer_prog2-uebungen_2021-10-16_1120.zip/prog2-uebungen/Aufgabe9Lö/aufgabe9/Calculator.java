package aufgabe9;
import javax.swing.*;
import java.awt.*;

public class Calculator extends JFrame {

    private Calculator() {
        this.setBackground(Color.gray);
        this.setTitle("Taschenrechner");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);

        Level1CalcClear c = new Level1CalcClear();
        this.add(c);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new Calculator();

    }
}
