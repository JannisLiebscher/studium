//Imports
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator
extends JFrame
implements ActionListener
{//Calculator
  private JLabel operandX;
  private JLabel operandY;
  private JLabel resultat;
  private double _doubleX;
  private double _doubleY;

  public Calculator()
  {//TopLevelContainer Calculator
    this.setTitle("Taschenrechner");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new FlowLayout());

    //Menu
    JMenuBar menuBar = new JMenuBar();
    menuBar.setOpaque(true);
    menuBar.setBackground(Color.black);
    menuBar.setPreferredSize(new Dimension(200, 20));
    menuBar.setToolTipText("Menu");

    //Panel
    JPanel panel = new JPanel();
    panel.setBackground(Color.white);
    panel.setPreferredSize(new Dimension(100, 90));

    //CheckBox
    JCheckBox lightTheme = new JCheckBox("Helles Display");
    lightTheme.setSelected(true);
    lightTheme.addItemListener(this);

    //JButton
    JButton plus = new JButton("+");
    this.add(plus);    //create object
    plus.addActionListener(this);

    JButton multiply = new JButton("*");
    this.add(multiply);
    multiply.addActionListener(this);

    JButton subtract = new JButton("-");
    this.add(subtract);
    subtract.addActionListener(this);

    JButton divide = new JButton("/");
    this.add(divide);
    divide.addActionListener(this);

    JButton sinus = new JButton("sin");
    this.add(sinus);
    sinus.addActionListener(this);

    JButton cosinus = new JButton("cos");
    this.add(cosinus);
    cosinus.addActionListener(this);

    JButton power = new JButton("x^y");
    this.add(power);
    power.addActionListener(this);

    JButton logarithm = new JButton("log2");
    this.add(logarithm);
    logarithm.addActionListener(this);

    //JLabel
    this.operandX = new JLabel("Operand x");
    this.add(operandX);   //class variable must be declared

    this.operandY = new JLabel("Operand y");
    this.add(operandY);

    this.resultat = new JLabel("Resultat");
    this.add(resultat);

    //JTextField
    JTextField opXTxt = new JTextField(10);
    opXTxt.addActionListener(this);

    JTextField opYTxt = new JTextField(10);
    opYTxt.addActionListener(this);

    JTextField resultTxt = new JTextField(10);

    //ActionListener
    void actionPerformed(ActionEvent plus)
    {

    }
  @Override
    void actionPerformed(ActionEvent e)
    {
      String _strX = opXTxt.getText();
      _doubleX = Double.parseDouble(String _strX);
      String _strY = opYTxt.getText();
      _doubleY = Double.parseDouble(String _strY);

      double result = _doubleX + _doubleY;
      double result = _doubleX * _doubleY;
      double result = _doubleX - _doubleY;
      double result = _doubleX / _doubleY;
      double result = Math.sin(_doubleX);
      double result = Math.cos(_doubleX);
      double result = Math.pow(_doubleX, _doubleY);
    }
    @Override
    this.pack();
    this.setVisible(true);
  }//TopLevelContainer Calculator

  public static void main(String[] args)
  {//main
    JFrame myApp = new Calculator();
  }//main
}//Calculator

/*Infos*/
/*
To appear onscreen, every GUI component must be part of a containment hierarchy
Each GUI component can be contained only once, he component will be removed from the first container and then added to the second

*/
