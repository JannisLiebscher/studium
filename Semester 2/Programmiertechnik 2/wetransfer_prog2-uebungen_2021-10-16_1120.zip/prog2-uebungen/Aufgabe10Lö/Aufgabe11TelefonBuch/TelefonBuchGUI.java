// O. Bittel
// 10.03.2017

package Aufgabe11TelefonBuch;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class TelefonBuchGUI extends JFrame {

    private TelefonBuch telBuch;
    private static TelefonBuchGUI myFrame;
    private JTextArea field;
    private JScrollPane scrollPane;

    public static TelefonBuchGUI getMyFrame() {
        return myFrame;
    }

    public JTextArea getField() {
        return field;
    }

    public TelefonBuchGUI() {
        // TelefonBuch anlegen:
        telBuch = new TelefonBuch();

        // Menuleiste einbauen:
        // ...
        this.setJMenuBar(new TelefonBuchMenuBar(telBuch));

        // mainPanel mit Umrandung versehen und das
        JPanel mainPanel = new JPanel();
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));

        // Einfuegen- und  SuchenLoeschenPanel einbauen:
        mainPanel.add(new TelefonBuchEinfuegenPanel(telBuch));
        mainPanel.add(new TelefonBuchSuchenLoeschenPanel(telBuch));
        // ...


        // Sonstige Eigenschaften des Hauptfenster setzen:
        JPanel panel = new JPanel();
        field = new JTextArea(10,10);

        field.setEditable(false);

        //Zeilenumbruch wird eingeschaltet
        field.setLineWrap(true);

        //Zeilenumbrüche erfolgen nur nach ganzen Wörtern
        field.setWrapStyleWord(true);


        Border border = BorderFactory.createTitledBorder("Ausgabe");
        panel.setLayout(new BorderLayout());
        panel.setBorder(border);

        scrollPane = new JScrollPane(field);
        panel.add(scrollPane);
        mainPanel.add(panel);

        this.setContentPane(mainPanel);

        this.setLocationRelativeTo(null);
        this.setTitle("Telefonbuch");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args) {
        myFrame = new TelefonBuchGUI();
    }
}
