// O. Bittel
// 10.03.2017

package Aufgabe11TelefonBuch;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.awt.event.*;

public class TelefonBuchMenuBar
        extends JMenuBar implements ActionListener {

    private TelefonBuch telBuch;
    private JMenu menu;
    private JMenuItem i1, i2, i3;
    private JFileChooser fileChooser;
    private JTextArea textArea;
    private File file;

    public TelefonBuchMenuBar(TelefonBuch tb) {
        telBuch = tb;

        fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        textArea = new JTextArea(20,80);
        textArea.setMargin(new Insets(5,5,5,5));
        textArea.setEditable(true);
        //JScrollPane logSchrollPane = new JScrollPane(textArea);

        menu = new JMenu("Datei");
        i1 = new JMenuItem("TelefonBuch lesen");
        i1.addActionListener(this);
        i2 = new JMenuItem("TelefonBuch speichern");
        i2.addActionListener(this);
        i3 = new JMenuItem("TelefonBuch beenden");
        i3.addActionListener(this);
        menu.add(i1); menu.add(i2); menu.add(i3);
        this.add(menu);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == i1) {
            int returnVal = fileChooser.showOpenDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                file = fileChooser.getSelectedFile();
                telBuch.read(file);
                textArea.append("Opening: " + file.getName() + "\n");
            } else {
                textArea.append("Open command cancelled by user.\n");
            }
            textArea.setCaretPosition(textArea.getDocument().getLength());
        }
        if (e.getSource() == i2) {
            int returnVal = fileChooser.showSaveDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                file = fileChooser.getSelectedFile();
                telBuch.save(file);
                textArea.append("Saving: " + file.getName() + "\n");
            } else {
                textArea.append("Saving command cancelled by user.\n");
            }
            textArea.setCaretPosition(textArea.getDocument().getLength());
        }
        if (e.getSource() == i3) {
            int n = JOptionPane.showConfirmDialog(
                    TelefonBuchGUI.getMyFrame(),
                    "Wollen Sie die Applikation wirklich beenden?",
                    "Bestätigung",
                    JOptionPane.YES_NO_OPTION
            );

            if (n == JOptionPane.YES_OPTION) {
                System.out.println("Die Applikation wird geschlossen");
                System.exit(0);
            } else if (n == JOptionPane.NO_OPTION) {
                System.out.println("Die Applikation wird fortgeführt");
            }
        }
    }
}

