// O. Bittel
// 10.03.2017

package Aufgabe11TelefonBuch;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.util.List;

public class TelefonBuchSuchenLoeschenPanel
        extends JPanel implements ActionListener {

    private TelefonBuch telBuch;
    private JTextField tfLoeschenName;
    private JTextField tfLoeschenZusatz;
    private JComboBox boxEinfuegen;
    private JButton buttonEinfuegen;


    public TelefonBuchSuchenLoeschenPanel(TelefonBuch tb) {
        telBuch = tb;

        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayout(2, 1));
        panel1.add(new JLabel("Name"));
        panel1.add(new JLabel("Zusatz"));

        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(2, 1));
        tfLoeschenName = new JTextField("", 20);
        panel2.add(tfLoeschenName);
        tfLoeschenZusatz = new JTextField("", 20);
        panel2.add(tfLoeschenZusatz);

        Border border = BorderFactory.createTitledBorder("Suchen/Löschen");
        this.setBorder(border);
        this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
        this.add(panel1);
        this.add(panel2);

        String[] possibilities = {"Exakte Suche", "Prefix-Suche", "Löschen"};

        boxEinfuegen = new JComboBox(possibilities);
        boxEinfuegen.setSelectedIndex(2);
        boxEinfuegen.addActionListener(this);
        this.add(boxEinfuegen);
        buttonEinfuegen = new JButton("Anwenden");
        buttonEinfuegen.addActionListener(this);
        this.add(buttonEinfuegen);

    }

    private static void print(List<String> strList) {
        for (String s : strList)
            TelefonBuchGUI.getMyFrame().getField().append(s + '\n');
    }

    public void actionPerformed(ActionEvent e) {

        int n = boxEinfuegen.getSelectedIndex();

        if (e.getSource() == buttonEinfuegen) {
            if (n == 0) {
                if (telBuch.exactSearch(tfLoeschenName.getText(), tfLoeschenZusatz.getText()) == null) {
                    JOptionPane.showMessageDialog(
                            TelefonBuchGUI.getMyFrame(),
                            "Could not be found",
                            "ERROR",
                            JOptionPane.ERROR_MESSAGE
                    );
                } else {
                    TelefonBuchGUI.getMyFrame().getField().append(telBuch.exactSearch(tfLoeschenName.getText(),
                            tfLoeschenZusatz.getText()));
                    TelefonBuchGUI.getMyFrame().getField().append("\n");
                }
            } else if (n == 1) {
                print(telBuch.prefixSearch(tfLoeschenName.getText()));
            } else if (n == 2) {
                telBuch.remove(tfLoeschenName.getText(), tfLoeschenZusatz.getText());
            }
        }
    }
}
