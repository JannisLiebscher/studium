package Aufgabe1;


import java.util.Arrays;

/**
 *
 * @author Tobias Latt
 * @since 24.03.2021
 */
public class ArrayFrequencyTable<T> extends AbstractFrequencyTable<T> {
	private int size;
	private Element<T>[] fqTable;
	private final int DEFAULT_SIZE = 100;

	public ArrayFrequencyTable() {
		clear();
	}

	public int size() {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		return this.size;
	}

	@Override
	@SuppressWarnings("unchecked")
	public final void clear() {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code:
		// ...
		this.size = 0;
		this.fqTable = (Element<T>[]) new Element[DEFAULT_SIZE];
	}


	// Sortieren des Arrays
	private void moveLeft(int pos) {
		Element<T> w = this.fqTable[pos];
		// Laufvariable
		while (pos >= 0 && w.getFrequency() > this.fqTable[pos - 1].getFrequency()) {
			this.fqTable[pos] = this.fqTable[pos - 1];
			pos--;
		}
		this.fqTable[pos] = w;
	}


	@Override
	public void add(T e, int f) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		if (e == null || f <= 0) {
			throw new IllegalArgumentException();
		}

		for (int i = 0; i < this.size(); i++) {
			if (this.fqTable[i].getData().equals(e)) {
				this.fqTable[i].addFrequency(f);
				this.moveLeft(i);
				return;
			}
		}
		if (this.size() == this.fqTable.length) {
			this.fqTable = Arrays.copyOf(this.fqTable, 2*this.size());
		}

		this.fqTable[this.size()] = new Element<T>(e, f);
		if (this.size() > 0) {
			this.moveLeft(this.size());
		}
		this.size++;
	}

	@Override
	public void add(T e) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		this.add(e, 1);
	}

	@Override
	public Element<T> get(int pos) {
		// throw muss noch auskommentiert werden!
		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code: 
		// ...
		return fqTable[pos];
	}

	@Override
	public int get(T data) {
		//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		// Ihr Code:
		// ...
		for (int i = 0; i < this.size(); i++) {
			if (this.fqTable[i].getData().equals(data)) {
				return this.fqTable[i].getFrequency();
			}
		}
		return 0;
	}
}