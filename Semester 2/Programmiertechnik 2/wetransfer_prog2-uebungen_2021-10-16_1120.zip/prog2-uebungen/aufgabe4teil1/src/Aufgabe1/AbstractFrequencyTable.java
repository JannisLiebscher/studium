package Aufgabe1;

/**
 *
 * @author Tobias Latt
 * @since 24.03.2021
 */
public abstract class AbstractFrequencyTable<T> implements FrequencyTable<T> {
	@Override
	public boolean isEmpty() {
		return this.size() == 0;
	}
	
	@Override
    public void add(T data) {
        add(data, 1);
    }

	@Override
	public void addAll(FrequencyTable<? extends T> fq) {
		if (fq != null) {
			for (int i = 0; i < fq.size(); i++) {
				this.add(fq.get(i).getData(),
						fq.get(i).getFrequency());
			}
		}
	}
	@Override
	public void collectMostFrequent(FrequencyTable<? super T> fq) {
		fq.clear();
		int most = this.get(0).getFrequency();

		for (int i = 0; i < this.size(); i++) {
			if (this.get(i).getFrequency() == most) {
				fq.add(this.get(i).getData(), most);
			} else {
				return;
			}
		}
	}


	@Override
	public void collectLeastFrequent(FrequencyTable<? super T> fq) {
		fq.clear();
		for (int i = 0; i < this.size(); i++) {
			if (this.get(i).getFrequency() == 1) {
				fq.add(this.get(i).getData(), 1);
			}
		}
	}

	/**
	 * Liefert eine String-Darstellung zur&uuml;ck.
	 * @return String-Darstellung.
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("{");
		for(int i = 0; i < this.size(); i++) {
			s.append(this.get(i).toString() + ", ");
		}
		s.append("}").append(" size = " + this.size());
		return s.toString();
	}
}