 public final class Aufgabe4 {
 private Aufgabe4() { }
 public static void main(final String[] args) {
 String s = "";
 for (String vorname: args) {
 System.out.print(s + vorname);
 char c = vorname.charAt(vorname.length() - 1);
 switch (c) {
 case 's':
 case 'x':
 case 'z':
 System.out.print('\'');
 break;
 default:
 System.out.print('s');
 }
 s = " und ";
 }
 System.out.println(" erstes Java-Programm funktioniert!");
 }
}