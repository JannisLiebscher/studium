// Notenstatistik.java
package aufgabe3;

import java.util.Locale;
import java.util.Scanner;

/**
 * erstellt eine Notenstatistik.
 * <p>
 * Das Programm erwartet Pr&uuml;fungsnoten im Format
 * <code>Ganze,Zehntel</code> oder <code>Ganze.Zehntel</code>,
 * wobei <code>Ganze</code> und <code>Zehntel</code> nur aus
 * je einer Dezimalziffer bestehen d&uuml;rfen.
 * Andere Eingaben werden wegen Formatfehler ignoriert.
 * </p>
 * <p>
 * Das Programm gibt die folgende Statistik aus:
 * </p>
 * <ul>
 * <li>die Anzahl der ber&uuml;cksichtigten Noten</li>
 * <li>die Anzahl der Bestandenen</li>
 * <li>die beste Note</li>
 * <li>die schlechteste Note</li>
 * <li>den Durchschnitt der Bestandenen</li>
 * <li>die Durchfallquote in Prozent</li>
 * </ul>
 * <p>
 * Es werden in der Statistik nur die nach HTWG-Pr&uuml;fungsordnung
 * zul&auml;ssigen Noten (1,0 1,3 1,7 2,0 2,3 2,7 3,0 3,3 3,7 4,0 5,0)
 * ber&uuml;cksichtigt.
 * Andere Eingaben werden wegen falscher Vorkommastelle oder
 * falscher Nachkommastelle ignoriert.
 * Alle Noten bis 4,0 gelten als bestanden, nur die 5,0 als durchgefallen.
 * </p>
 *
 * @author Tobias Latt
 * @version 08.12.2020
 */
public final class Notenstatistik {
    private Notenstatistik() { }

    private static final Scanner EINGABE = new Scanner(System.in);

    /**
     * main ist der Startpunkt des Programms.
     * @param args wird nicht verwendet.
     */
    public static void main(String[] args) {
        Locale.setDefault(Locale.GERMANY);

        //--------------------------------------------------- Noten einlesen
        System.out.println("Noten im Format Ganze,Zehntel "
                           + "oder Ganze.Zehntel eingeben (Ende mit Strg-Z):");

        double bestandeneNoten = 0;
        double besteNote = 5.0;
        double schlechtesteNote = 0.0;
        int anzahlbestanden = 0;
        int anzahlNoten = 0;
        double durchschnitt = 0;
        double summe = 0;
        double durchfallquote = 0;

        while (EINGABE.hasNext()) {
            String note = EINGABE.next();

            //---------------------------------------------- Eingabe pruefen

            /* die Zeichen im String note pruefen ... */
            double ak = 0.0;
            if (!(note.length() == 3
                    && (Character.isDigit(note.charAt(0)))
                    && (Character.isDigit(note.charAt(2)))
                    && (note.contains(".") || note.contains(",")))) {
                String v1 = " wird wegen Formatfehler ignoriert!%n";
                String falleins = "Note " + note + v1;
                System.out.printf(falleins, note);
                continue;

            } else {

                int fd = Character.getNumericValue(note.charAt(0));
                int td = Character.getNumericValue(note.charAt(2));
                switch (note.charAt(0)) {

                case '1':
                case '2':
                case '3':
                    if (td == 0 || td == 3 || td == 7) {

                        String value1 = String.valueOf(fd);
                        String value2 = String.valueOf(td);
                        ak = Double.parseDouble(value1 + "." + value2);
                        anzahlNoten = anzahlNoten + 1;
                        anzahlbestanden = anzahlbestanden + 1;
                        bestandeneNoten = bestandeneNoten + ak;
                    } else {
                        String v3 = " Nachkommastelle %d ignoriert!%n";
                        System.out.printf("Note %s wird wegen" + v3, note, td);
                    }
                    break;
                case '4':
                    if (td == 0) {
                        String value1 = String.valueOf(fd);
                        String value2 = String.valueOf(td);
                        ak = Double.parseDouble(value1 + "." + value2);
                        anzahlNoten = anzahlNoten + 1;
                        anzahlbestanden = anzahlbestanden + 1;
                        bestandeneNoten = bestandeneNoten + ak;
                    } else {
                        String v3 = " Nachkommastelle %d ignoriert!%n";
                        System.out.printf("Note %s wird wegen" + v3, note, td);
                    }
                    break;

                case '5':
                    if (td == 0) {
                        String value1 = String.valueOf(fd);
                        String value2 = String.valueOf(td);
                        ak = Double.parseDouble(value1 + "." + value2);
                        anzahlNoten = anzahlNoten + 1;
                    } else {
                        String v3 = " Nachkommastelle %d ignoriert!%n";
                        System.out.printf("Note %s wird wegen" + v3, note, td);
                    }
                default:
                    break;
                case '0':
                case '6':
                case '7':
                case '8':
                case '9':
                    String v5 = " Vorkommastelle %d ignoriert!%n";
                    System.out.printf("Note %s wird wegen" + v5, note, fd);
                }
            }
            if (ak < besteNote && ak != 0) {
                besteNote = ak;
            }
            if (ak > schlechtesteNote) {
                schlechtesteNote = ak;
            }
            //------------------------------------------------ Note erfassen
        }  // while

        /* Notensumme Bestandene, Anzahl Bestandene,
                     Anzahl Durchgefallene sowie
                     beste und schlechteste Note aktualisieren ... */

        durchschnitt = (bestandeneNoten / anzahlbestanden);
        durchfallquote = (1 - (double) anzahlbestanden / anzahlNoten) * 100;
        double ten = 10;
        durchfallquote = Math.round(durchfallquote * ten) / ten;

        //------------------------------------------ Notenstatistik ausgeben

        /* Durchschnitt und Durchfallquote berechnen
                     und dann die gesamte Statistik ausgeben ... */

        System.out.println(" ");
        System.out.printf("Anzahl beruecksichtigter Noten: %d%n", anzahlNoten);
        System.out.printf("Anzahl Bestandene: %d%n", anzahlbestanden);
        if (anzahlbestanden != 0) {
            System.out.printf("Beste Note: %.1f%n", besteNote);
            System.out.printf("Schlechteste Note: %.1f%n", schlechtesteNote);
            System.out.printf("Durchschnitt Bestandene: %.1f%n", durchschnitt);
            System.out.printf("Durchfallquote: %.1f", durchfallquote);
            System.out.println("%");

        }
    }
}
// main






