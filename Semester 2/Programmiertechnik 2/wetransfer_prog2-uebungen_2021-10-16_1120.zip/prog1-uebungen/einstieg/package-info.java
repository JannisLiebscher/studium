/**

Paket der ersten &Uuml;bungsstunde Programmiertechnik 1 f&uuml;r AIN/1.

@see <a href="http://www-home.htwg-konstanz.de/~drachen/prog1/Uebungen.pdf">
     Anleitungen zu den &Uuml;bungen</a>

@author  H.Drachenfels
@version 6.11.2015

*/

package einstieg;

