//* FachNote.java
package aufgabe5;

/**
 * Instanziierbarte Klasse FachNote für Werteobjekte.
 * @author Tobias Latt
 * @version 17.01.2021
 */

public final class FachNote {

/**
 * Schulfächer.
 */

    public final String fach;

/**
 * Note mit dem Wert der note.
 */

    public final Note note;

/**
 * Konstruktor.
 * @param fach ist ein Schulfach
 * @param note ist eine Note
 */

    public FachNote(String fach, Note note) {
        if (fach != null
                && note != null
                && fach.length() != 0) {
            this.fach = fach;
            this.note = note;
        } else {
            throw new IllegalArgumentException();
        }
    }
}