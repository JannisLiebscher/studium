//* Note.java
package aufgabe5;

/**
 * Instanziierbarte Klasse Note für Werteobjekte.
 * @author Tobias Latt
 * @version 17.01.2021
 */

public final class Note {

    private final int note;
    private Note(int note) {
        this.note = note;
    }

    /**
        * BESTE ist die best moegliche Note.
        */

    public static final Note BESTE = new Note(10);

    /**
    * SCHLECHTESTE ist die schlechst moegliche Note.
    */

    public static final Note SCHLECHTESTE = new Note(50);

    /**
    * istZulaessig prueft ob Note zulaessig ist.
    * @param note ist die zu pruefende Note.
    * @return true wenn Note zulaessig.
    */

    public static Note valueOf(int note) {
        Note ausgabe;
        switch (note) {
        case 10:
        case 13:
        case 17:
        case 20:
        case 23:
        case 27:
        case 30:
        case 33:
        case 37:
        case 40:
        case 50:
            ausgabe = new Note(note);
            return ausgabe;
        default:
            throw new IllegalArgumentException("unzulaessige Note " + note);
        }
    }

/**
 * Note wird auf zulaessig geprüft.
 * @param n checkt ob die note valide ist
 * @return gibt den wert der zulaessigen note wieder
 */

    public static Note valueOf(String n) {
        if (!n.matches("[1-3][,][037]")
                && !n.matches("[45][,][0]")) {
            throw new IllegalArgumentException("unzulaessige Note " + n);
        }
        n = n.replace(",", "");
        int b = Integer.parseInt(n);
        return new Note(b);
    }

/**
 * Gibt den value der note wieder.
 * @return gibt den intValue der note wieder
 */

    public int intValue() {
        return this.note;
    }

/**
 * es wird auf bestanden geprüft.
 * @return gibt einen boolean Wert wieder
 */

    public boolean istBestanden() {
        if (note > 9 && this.note < 41) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        String n = String.valueOf(this.note);
        n = n.charAt(0) + "," + n.charAt(1);
        return n;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Note) {
            Note that = (Note) o;
            return this.note == that.note;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.note;
    }
}






