// Notenspiegel.java
package aufgabe5;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Notenspiegel liest die Namen von F&auml;chern mit den zugeh&ouml;rigen Noten
 * in eine verkettete Liste ein und gibt dann einen Notenspiegel aus.
 * @author Tobias Latt
 * @version 18.01.2021
 */
public final class Notenspiegel {
    private Notenspiegel() { }

    private static final Scanner EINGABE = new Scanner(System.in);

    /**
     * main ist der Startpunkt des Programms.
     * @param args wird nicht verwendet.
     */
    public static void main(String[] args) {
        FachNotenListe liste = new FachNotenListe(); // leere Liste

        //--------------------------------------------- Notenspiegel einlesen
        System.err.printf(
            "Faecher mit Noten zwischen %d und %d eingeben "
            + "(Ende mit Strg-Z):%n",
            Note.BESTE.intValue(), Note.SCHLECHTESTE.intValue());

        while (EINGABE.hasNext()) {
            try {
                //------------------------------------ Fach und Note einlesen.
                String fach = EINGABE.next();
                Note note;
                if (EINGABE.hasNextInt()) {
                    note = Note.valueOf(EINGABE.nextInt());
                } else {
                    note = Note.valueOf(EINGABE.next());
                }

                //--------------------- neue Fachnote in Notenliste eintragen


                FachNote fn = new FachNote(fach, note);
                liste = liste.insert(fn);

            } catch (IllegalArgumentException x) {
                System.err.printf("Eingabefehler: %s%n", x.getMessage());
                continue;
            } catch (NoSuchElementException x) {
                System.err.println("Fach ohne Note ignoriert!");
                break;
            }
        }

        //--------------------------------------------- Notenspiegel ausgeben


        System.out.println("\nNOTENSPIEGEL");
        FachNotenListe.Iterator iterator = liste.new Iterator();

        int laenge = 0;
        while (iterator.hasNext()) {
            FachNote temp = iterator.next();
            if (temp.fach.length() > laenge) {
                laenge = temp.fach.length();
            }
        }
        iterator = liste.new Iterator();
        while (iterator.hasNext()) {
            FachNote temp = iterator.next();
            System.out.print(temp.fach + " ");
            for (int i = temp.fach.length(); i < laenge; i++) {
                System.out.print(" ");
            }
            System.out.print(temp.note.toString() + " ");
            if (temp.note.istBestanden()) {

                if (temp.note.equals(Note.BESTE)) {
                    System.out.println("mit Bestnote bestanden");
                } else {
                    System.out.println("bestanden");

                }
            } else {
                System.out.println("nicht bestanden");
            }


        }


    } // main
}

