// Noten.java
package aufgabe4.schweiz;
//import aufgabe4.schweiz.Noten;

/**
* @author Tobias Latt
* @version 28.12.2020
*/

public final class Noten {
    private Noten() { }

    //Konstante für beste & schlechteste Noten

    /** Referenz zur bestmöglichen Note. */

    public static final double BESTE = 6.0;

    /** Referenz zur schlechtestmöglichen Note. */

    public static final double SCHLECHTESTE = 1.0;

    /** @return isNote
    * @param note String wird übergeben sowie überprüft.
    */


    public static boolean istZulaessig(String note) {
        boolean isNote = false;
        if ((note.length() == 3)
                && (Character.isDigit(note.charAt(0)))
                && (Character.isDigit(note.charAt(2)))
                && (note.charAt(1) == ',' || note.charAt(1) == '.')) {
            isNote = true;

        } else {
            if (note.length() == 1
                    && Character.isDigit(note.charAt(0))) {
                isNote = true;
            }
            return isNote; // return
        }
    }

    /** @return notes gibt double Wert zurück.
    * @param note ist ein String Wert.
    */
    public static double toDouble(String note) {
        double notes = 0;
        boolean fehler = true;

        if (istZulaessig(note)) {
            fehler = false;
            char vorkomma = note.charAt(0);
            char nachkomma = '0';
            if (note.length() != 1) {
                nachkomma = note.charAt(2);
                float x = Integer.parseInt(String.valueOf(vorkomma));
                float y = 0;
            }
            if (note.length() != 1) {
                y = Integer.parseInt(String.valueOf(nachkomma));
            }
            if (((nachkomma == '0'
                    || nachkomma == '5')
                    && (x >= SCHLECHTESTE && x < BESTE))
                    || (x == 6 && y == 0)) {
                notes = (x + (y / 10));
            } else {
                fehler = true;
            }
        }
        try {
            if (fehler) {
                throw new IllegalArgumentException("Unzulaessige Note "
                                                   + note + " wird ignoriert!");
            }
        } catch (IllegalArgumentException i) {
            System.out.println("Unzulaessige Note "
                               + note + " wird ignoriert!");
        }
        return notes;
    }

    /** @return zahl gibt Eingabe als String zurück.
    * @param note ist ein double Wert.
    */

    public static String toString(double note) {
        int y = (int) note;
        note -= y;
        int z = (int) Math.round((note) * 1000) / 100;
        String zahl = y + "," + z;
        return zahl;
    }

    /** @return passed gibt bestandene Noten zurück.
    * @param note wird auf bestanden überprüft.
    */

    public static boolean istBestanden(double note) {
        boolean passed = false;
        if (note >= 4) {
            passed = true;
        }
        return passed;
    }

    /** @return besser Note wird zurückgegeben.
    * @param note1 prüft auf besser Note.
    * @param note2 prüft auf besser Note.
    */

    public static double bessere(double note1, double note2) {
        double besser;
        if (note1 > note2) {
            besser = note1;
        } else {
            besser = note2;
        }
        return besser;
    }

    /** @return schlechter Note wird zurückgegeben.
    * @param note1 prüft auf schlechtere Note.
    * @param note2 prüft auf schlechtere Note.
    */

    public static double schlechtere(double note1, double note2) {
        double schlechter;
        if (note1 > note2) {
            schlechter = note2;
        } else {
            schlechter = note1;
        }
        return schlechter;
    }
}































