// Klausurergebnis.java
package aufgabe4;
//import aufgabe4.schweiz.Noten;
import aufgabe4.schweiz.Noten;
import java.util.Locale;
import java.util.Scanner;

/**
 * Klausurergebnis erstellt eine Notenstatistik.
 * <p>
 * Das Programm liest Noten als Strings ein und bestimmt die beste und
 * die schlechteste Note, den Durchschnitt der Bestandenen sowie
 * die Durchfallquote in Prozent.
 * Das Programm ber&uuml;cksichtigt dabei nur die laut Noten.istZulaessig
 * erlaubten Noten. Andere Noten werden unter Ausgabe einer Warnung ignoriert.
 * Welche Noten besser und schlechter sind, welche als bestanden oder
 * durchgefallen gelten und wie die String-Darstellung der Noten aussieht,
 * wird mit Methoden der Klasse Noten bestimmt.
 * </p>
 * Das Programm gibt als Klausurergebnis folgende Werte aus:
 * <ul>
 * <li>die Anzahl der ber&uuml;cksichtigten Noten</li>
 * <li>die Anzahl der Bestandenen</li>
 * <li>die beste Note</li>
 * <li>die schlechteste Note</li>
 * <li>den Durchschnitt der Bestandenen</li>
 * <li>die Durchfallquote</li>
 * </ul>
 *
 * @author Tobias Latt
 * @version 28.12.2020
 */
public final class Klausurergebnis {
    private Klausurergebnis() { }

    private static final double X = 1;
    private static double besteNote = X;
    private static double durchschnitt = 0.0;
    private static final double Z = 6;
    private static double schlechtesteNote = Z;
    private static double durchgefallen = 0;
    private static int bestanden = 0;
    private static int total = 0;
    private static final int HUNDRED = 100;
    private static final int TEN = 10;


    private static final Scanner EINGABE = new Scanner(System.in);

    /**
     * main ist der Startpunkt des Programms.
     * @param args wird nicht verwendet.
     */
    public static void main(String[] args) {
        Locale.setDefault(Locale.GERMAN);




        //--------------------------------------------------- Noten einlesen
        System.out.println("Noten im Format Ganze,Zehntel "
                           + "oder Ganze.Zehntel eingeben (Ende mit Strg-D):");

        while (EINGABE.hasNext()) {
            String note = EINGABE.next();

            //---------------------------------------------- Eingabe pruefen
            double notes = Noten.toDouble(note);
            if (notes != 0) {
                total++;
                besteNote = Noten.bessere(besteNote, notes);
                schlechtesteNote = Noten.schlechtere(schlechtesteNote, notes);
                if (Noten.istBestanden(notes)) {
                    durchschnitt += notes;
                    bestanden++;
                } else {
                    durchgefallen++;
                }





                /* die Zeichen im String note pruefen ... */

            }
            //------------------------------------------------ Note erfassen
        }  // while

        /* Notensumme Bestandene, Anzahl Bestandene,
                     Anzahl Durchgefallene sowie
                     beste und schlechteste Note aktualisieren ... */

        //------------------------------------------ Notenstatistik ausgeben

        /* Durchschnitt und Durchfallquote berechnen
                     und dann die gesamte Statistik ausgeben ... */
        if (total != 0) {
            durchschnitt /= bestanden;
            durchgefallen = ((1 - (double) bestanden / total) * HUNDRED);
            final double ten = 10;
            durchgefallen = Math.round(durchgefallen * ten) / ten;
            System.out.println("Anzahl beruecksichtigter Noten: " + total
                               + "\nAnzahl Bestandene: " + bestanden
                               + "\nBeste Note: " + Noten.toString(besteNote)
                               + "\nSchlechteste Note: "
                               + Noten.toString(schlechtesteNote)
                               + "\nDurchschnitt Bestandene: "
                               + Noten.toString(durchschnitt)
                               + "\nDurchfallquote: "
                               + Noten.toString(durchgefallen) + "%");


        }
    }
}
// main


