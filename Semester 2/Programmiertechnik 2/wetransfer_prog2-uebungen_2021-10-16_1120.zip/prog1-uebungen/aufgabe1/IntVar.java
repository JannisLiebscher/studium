// IntVar.java

package aufgabe1;

import java.util.Scanner;

/**
 * IntVar zeigt den Umgang mit Variablen vom Typ int.
 * &Uuml;bungsaufgabe 1 zur Programmiertechnik 1.
 * @author Tobias Latt
 * @version 29.10.2020
 */
public final class IntVar {
    private IntVar() { }

    private static final Scanner EINGABE = new Scanner(System.in);

    /**
     * main ist der Startpunkt des Programms.
     * @param args wird nicht verwendet.
     */
    public static void main(String[] args) {
        int x = 0;
        int y = 0;

        /* Konstanten min und max definieren */
        int intMin = Integer.MIN_VALUE;
        int intMax = Integer.MAX_VALUE;
        System.out.println("minimaler wert: " + intMin);
        System.out.println("maximaler wert: " + intMax);



        /* Eingabeaufforderung ausgeben */
        /* zwei ganze Zahlen einlesen */

        System.out.print("Geben Sie 2 ganze Zahlen, zwischen");
        System.out.println("dem max. int & min. int Wert ein.");
        x = EINGABE.nextInt(); y = EINGABE.nextInt();


        /* die beiden Zahlen dezimal, okatal und hexadezimal ausgeben */
        System.out.printf("%d ist oktal %o und hexadezimal %x%n", x, x, x);
        System.out.printf("%d ist oktal %o und hexadezimal %x%n", y, y, y);






        /* alle zweistelligen arithmetischen Operatoren ausprobieren */
        System.out.println(x + " + " + y + " ist " + (x + y));
        System.out.println(x + " - " + y + " ist " + (x - y));
        System.out.println(x + " * " + y + " ist " + (x * y));
        System.out.println(x + " / " + y + " ist " + (x / y));
        System.out.println(x + " % " + y + " ist " + (x % y));






        /* alle Vergleichsoperatoren ausprobieren */
        System.out.println(x + " == " + y + " ist " + (x == y));
        System.out.println(x + " != " + y + " ist " + (x != y));
        System.out.println(x + " < " + y + " ist " + (x < y));
        System.out.println(x + " <= " + y + " ist " + (x <= y));
        System.out.println(x + " > " + y + " ist " + (x > y));
        System.out.println(x + " >= " + y + " ist " + (x >= y));






    }
}

