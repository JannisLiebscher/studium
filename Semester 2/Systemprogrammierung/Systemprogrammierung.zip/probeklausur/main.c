#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int x = argc - 1;

    int y = 0;
    for (x; x > 0; x--) {
        y += atoi(argv[x]);
        printf("%d",atoi(argv[x]));
    }
    printf("%s!\n", y);
    return 0;
}