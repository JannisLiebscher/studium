#include <stdio.h>
#include <locale.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

int main (int argc, char *argv[])
{
    if (setlocale(LC_MESSAGES, "de_DE.UTF-8") == NULL)
    {
        fprintf(stderr,
                "Plattform unterstützt deutsche Systemmeldungen nicht (errno %d: %s)\n",
                errno, strerror(errno));
    }

    if (argc != 3)
    {
        fprintf(stderr, "Aufruf: \"%s\" Quelle Ziel\n", argv[0]);
        return -1;
    }

    int in = open(argv[1], O_RDONLY);
    if (in == -1)
    {
        fprintf(stderr,
                "Quelle \"%s\" kann nicht geöffnet werden (errno %d: %s)\n",
                argv[1], errno, strerror(errno));
        return -1;
    }

    const mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
    int out = open(argv[2], O_WRONLY | O_CREAT | O_EXCL, mode);
    if (out == -1)
    {
        fprintf(stderr,
                "Ziel \"%s\" kann nicht erzeugt werden (errno %d: %s)\n",
                argv[2], errno, strerror(errno));
        return -1;
    }

    struct stat buffer;
    ssize_t statin = fstat(in, &buffer);
    if (statin == -1)
    {
        fprintf(stderr, "Quelle \"%s\" kann nicht gefunden werden"
                "(errno %d : %s)\n", argv[1], errno, strerror(errno));
        return -1;
    }

    char *temp = (char *) malloc(buffer.st_size * sizeof(char));
    if (temp == NULL)
    {
        printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
        return -1;
    }


    ssize_t statr = read(in, temp, buffer.st_size);
    if (statr == -1)
    {
        fprintf(stderr,
                "Lesefehler (errno %d: %s)\n",
                    errno, strerror(errno));
        free(temp);
        return -1;
    }
    else if (statr > buffer.st_size)
    {
    	fprintf(stderr, "Zu wenig Platz zur Erzeugung des Programms");
    	free(temp);
   		return -1;
    }

    ssize_t statw = write(out, temp, buffer.st_size);
    if (statw == -1)
    {
        fprintf(stderr,
                "Schreibfehler (errno %d: %s)\n",
                errno, strerror(errno));
        free(temp);
        return -1; 
    }
    else if (statw > buffer.st_size)
    {
    	fprintf(stderr, "Zu wenig Platz zur Erzeugung des Programms");
    	free(temp);
   		return -1;
    }
    else if (statw == 0)
    {
   		fprintf(stderr, "Fehler beim übertragen der Datei, da nicht spezifiziert");
   		free(temp);
   		return -1;
   	}

    printf("Erfolgreich kopiert!\n");

    free(temp);
    close(in);
    close(out);

    return 0;
}
