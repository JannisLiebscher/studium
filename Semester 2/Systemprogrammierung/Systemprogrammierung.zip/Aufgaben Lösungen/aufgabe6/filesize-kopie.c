#include <stdio.h>
#include <locale.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>


int main(int argc, char*argv[])
{
    setlocale(LC_ALL, "");

    ssize_t bytes = 0;

    if (argc < 2)
    {
        char c;
        while (read(0, &c, 1) > 0)
        {
            bytes++;
        }

        printf("Die Größe der Datei beträgt: %ld Bytes\n", bytes);
    }
    else
    {
        for (int i = 1; i < argc; i++)
        {
            struct stat s;
            if (stat(argv[i], &s) != 0)
            {
                fprintf(stderr, "Quelle \"%s\" kann nicht gefunden werden"
                        "(errno %d : %s)\n", argv[i], errno, strerror(errno));
                return -1;
            }
            if (S_ISDIR(s.st_mode))
            {
                fprintf(stderr, "Verzeichnis \"%s\" wurde ausgewählt"
                        "(errno %d : %s)\n", argv[i], errno, strerror(errno));
                return -1;
            }
            bytes = s.st_size;

            printf("Die Größe der Datei beträgt: %ld Bytes\n", bytes);
        }

    }

    return 0;
}
