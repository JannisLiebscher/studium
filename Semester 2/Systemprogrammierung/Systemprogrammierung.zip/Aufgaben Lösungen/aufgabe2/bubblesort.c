#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{

    // Ueberpruefen ob Laenge des Arrays ok ist
    if (argc != 2)
    {
        printf("Aufruf: java Bubblesort Anzahl\n");
        return -1;
    }

    const int size = atoi(argv[1]);
    int *array = (int*) malloc(sizeof(int) * size);
    srand((unsigned int) time(NULL));

    // einlesen
    int k = 0;

    for (int i = 0; i < size && scanf("%d", &array[i]) > 0; ++i)
    {
        k = 1;
    }
    for (int i = 0; i < size && k == 0; ++i)
    {
        array[i] = rand();
    }

    // sortieren
    for (int i = size; i > 1; i--)
    {
        for (int j = 0; j < i - 1; ++j)
        {
            if (array[j] >  array[j + 1])
            {
                int tmp = array[j + 1];
                array[j + 1] = array[j];
                array[j] = tmp;
            }
        }
    }

    // ausgeben
    for (int i = 0; i < size; ++i)
    {
        //printf("argv[%d]: %d\n", i, array[i]);
        printf("%d\n", array[i]);
    }

    free(array);
    return 0;
}
