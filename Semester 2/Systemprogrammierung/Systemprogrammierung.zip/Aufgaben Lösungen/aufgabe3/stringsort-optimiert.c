#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <string.h>

int main(int argc, char *argv[])
{

    char *ausgabe;

    //einlesen

    srand((unsigned int)time(NULL));
    if (argc != 2)
    {
        printf("\nAufruf: java Stringsort Anzahl\n\n");
        return 1;
    }

    if (argc == 0)
    {
        printf("\nAnzahl muss midestens 1 sein\n\n");
        return 1;
    }

    int zahl = atoi(argv[1]);
    unsigned int m = strlen(argv[1]) + 1;
    char *array = (char *)malloc(zahl * m * sizeof(char *));
    if (array == NULL)
    {
        printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
        free(array);
        return -1;
    }
    char *tmp = (char *)malloc(m * sizeof(char *));
    if (tmp == NULL)
    {
        printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
        return -1;
    }
    /* einlesen */

    printf("Unsortiertes Feld: ");
    for (int i = 0; i < zahl; i++)
    {
        int num = rand() % zahl;
        sprintf(array + (i * m), "%d", num);
        printf("%s ", array + i * m);
    }
    printf("\n");

    //sortieren

    for (int i = zahl; i > 1; i--)
    {
        for (int j = 0; j < i - 1; j++)
        {
            if ((strcmp(array + j * m, array + (j + 1) * m)) > 0)
            {
                memcpy(tmp, array + (j + 1) * m, m);
                memcpy(array + m * (j + 1), array + m * (j), m);
                memcpy(array + m * (j), tmp, m);
            }
        }
    }

    ausgabe = (char *)calloc(zahl * m, sizeof(char));
    if (ausgabe == NULL)
    {
        printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
        free(ausgabe);
        return -1;
    }
    printf("Sortiertes   Feld: ");

    strcpy(ausgabe, array);
    for (int i = 1; i < zahl; ++i)
    {
        if ((strcmp(array + (i - 1) * m, array + i * m)) != 0)
        {
            strcat(ausgabe, " ");
            strcat(ausgabe, array + i * m);
        }
        else
        {
            strcat(ausgabe, "*");
        }
    }
    printf("%s\n", ausgabe);

    free(tmp);
    free(array);
    free(ausgabe);
    return 0;
}
