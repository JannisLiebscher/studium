/**
 * stringsort.c
 * Aufgabe 3, Systemprogrammierung
 * @author Matthias Reichenbach
 * @version 01.05.2019
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stddef.h>

int main(int argc, char *argv[])
{
    // ueberpruefen ob es eine Eingabe gab
    if (argc != 2)
    {
        printf("Aufruf: Stringsort Anzahl\n");
        return -1;
    }

    srand((unsigned int) time(NULL));
    unsigned int m = strlen(argv[1]) + 1;
    const unsigned int size = (const unsigned int) atoi(argv[1]);
    if (size < 1)
    {
        printf("Die Anzahl muss mindestens 1 sein\n");
        return -1;
    }
    char **array = (char**) malloc(sizeof(char*) * size);
    if (array == NULL)
    {
        printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
        return -1;
    }

    //Zahlen wuerfeln und in array schreiben und ausgeben
    printf("Unsortiertes Feld: ");
    for (unsigned int i = 0; i < size; ++i)
    {
        int randZahl = rand() % size;

        array[i] = (char*) malloc(sizeof(m));
        if (array[i] == NULL)
        {
            printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
            return -1;
        }
        sprintf(array[i], "%d", randZahl);
        printf("%s ", array[i]);
    }
    printf("\n");

    //sortieren
    for (int i = size; i > 1; i--)
    {
        for (int j = 0; j < i - 1; ++j)
        {
            if (strcmp(array[j], array[j + 1]) > 0)
            {
                char *tmp = array[j + 1];
                array[j + 1] = array[j];
                array[j]  = tmp;
            }
        }
    }

    //array in einen String schreiben
    char *ausgabe = (char*) malloc(sizeof(char) * size * m);
    if (ausgabe == NULL)
    {
        printf("Der Speicher reicht nicht fuer die Ausfuehrung des Programmes aus");
        return -1;
    }
    strcpy(ausgabe, array[0]);
    for (unsigned int i = 1; i < size; ++i)
    {
        if (strcmp(array[i], array[i - 1]) != 0)
        {
            strcat(ausgabe, " ");
            strcat(ausgabe, array[i]);
        }
        else
        {
            strcat(ausgabe, "*");
        }
    }
    // ausgabe sortiert
    printf("Sortiertes   Feld: %s\n", ausgabe);

    //reserierten Speicher freigeben
    for (unsigned int i = 0; i < size; i++)
    {
        free(array[i]);
    }
    free(ausgabe);
    free(array);
    return 0;
}
