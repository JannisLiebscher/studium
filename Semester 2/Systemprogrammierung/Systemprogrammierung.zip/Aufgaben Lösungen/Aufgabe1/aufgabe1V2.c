#include <stdio.h>

int main()
{

    int var01 = 1;
    short int var02  = 2;
    long int var03 = 3;
    long long int var04 = 4;
    float var05 = 5;
    double var06 = 6;
    long double var07 = 7;
    char var08 = 'a';

    signed char var09 = -1;
    unsigned char var10 = 0xff;
    unsigned int var11 = 0xffffffffU;
    unsigned short int var12 = 0xffffU;
    unsigned long int var13 = 0xffU;
    unsigned long long int var14 = 0xfU;

    const char* s = "Hallo";

    printf("Adresse: %p | Platzbedarf: %zu  | Typ: int                    | "
           "Name: var01 | Wert: %d\n",
           (void*) &var01, sizeof(int), var01);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: short int              | "
           "Name: var02 | Wert: %hd\n",
           (void*) &var02, sizeof(short int), var02);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: long int               | "
           "Name: var03 | Wert: %li\n",
           (void*) &var03, sizeof(long int), var03);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: long long int          | "
           "Name: var04 | Wert: %lli\n",
           (void*) &var04, sizeof(long long int), var04);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: float                  | "
           "Name: var05 | Wert: %f\n",
           (void*) &var05, sizeof(float), var05);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: double                 | "
           "Name: var06 | Wert: %f\n",
           (void*) &var06, sizeof(double), var06);
    printf("Adresse: %p | Platzbedarf: %zu | Typ: long double            | "
           "Name: var07 | Wert: %Lf\n",
           (void*) &var07, sizeof(long double), var07);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: char                   | "
           "Name: var08 | Wert: %c\n",
           (void*) &var08, sizeof(char), var08);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: signed char            | "
           "Name: var09 | Wert: %i\n",
           (void*) &var09, sizeof(signed char), var09);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: unsigned char          | "
           "Name: var10 | Wert: %u\n",
           (void*) &var10, sizeof(unsigned char), var10);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: unsigned int           | "
           "Name: var11 | Wert: %u\n",
           (void*) &var11, sizeof(unsigned int), var11);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: unsigned short int     | "
           "Name: var12 | Wert: %i\n",
           (void*) &var12, sizeof(unsigned short int), var12);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: unsigned long int      | "
           "Name: var13 | Wert: %lu\n",
           (void*) &var13, sizeof(unsigned long int), var13);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: unsigned long long int | "
           "Name: var14 | Wert: %llu\n",
           (void*) &var14, sizeof(unsigned long long int), var14);
    printf("Adresse: %p | Platzbedarf: %zu  | Typ: char*                  | "
           "Name:     s | Wert: %s\n",
           (void*) &s, sizeof(char*), s);

    if  (sizeof(int) == 4 && sizeof(char*) == 4 && sizeof(long int) == 4)
    {
        printf("\nDas Datenmodell ist ILP32\n");
    }
    else if (sizeof(int) == 4 && sizeof(long int) == 8 && sizeof(char*) == 8)
    {
        printf("\nDas Datenmodell ist LP64\n");
    }
    else if (sizeof(int) == 4 &&  sizeof(long int) == 4
             && sizeof(char*) == 8 && sizeof(long long int) == 8)
    {
        printf("\nDas Datenmodell ist LLP64\n");
    }
    else
    {
        printf("\nEs ist ein Fehler aufgetreten!\n\n");
    }

    return 0;
}
