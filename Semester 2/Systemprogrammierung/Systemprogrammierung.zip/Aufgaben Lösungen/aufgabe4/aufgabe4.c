/*
 * aufgabe4.c
 *
 * Liest Fachnamen mit Beurteilung ein und gibt dann einen Notenspiegel aus.
 *
 * Autor: Matthias Reichenbach
 * Erstellt am: 08.05.2019
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define size 20
typedef struct fach_note fach_note;

enum benotet_oder_unbenotet {benotet, unbenotet};
struct fach_note
{
    fach_note *prev;
    fach_note *next;
    char fachname[size + 1];
    enum benotet_oder_unbenotet u_benotet ;
    union
    {
        int note;
        char ub;
    };
};

void schleife(fach_note *, void (*) (fach_note const *) );
int einlesen(fach_note*);
fach_note *einfuegen(fach_note *, fach_note *);
fach_note *entfernen(fach_note *, fach_note **);
void ausgeben(fach_note const *);

int main(void)
{
    fach_note *notenspiegel = NULL;

    //------------------------------------------- Notenspiegel einlesen
    fprintf(stderr, "Faecher mit Noten eingeben (Ende mit Strg-D):\n");

    for (;;)
    {
        fach_note *p = (fach_note *) malloc(sizeof (fach_note));
        if (p == NULL)
        {
            fprintf(stderr, "Zu viele Faecher!\n");
            break;
        }

        if (! einlesen(p))
        {
            fprintf(stderr, "Eingabeende!\n");
            free(p);
            break;
        }

        notenspiegel = einfuegen(notenspiegel, p);
    }

    //------------------------------------------- Notenspiegel ausgeben
    printf("Notenspiegel:\n");

    schleife(notenspiegel, ausgeben);

    //------------------------------------------- Notenspiegel loeschen
    while (notenspiegel != NULL)
    {
        fach_note *p;
        notenspiegel = entfernen(notenspiegel, &p);
        free(p);
    }
    return 0;
}

int einlesen(fach_note *fach)
{
    unsigned int note;
    int test;

    test = scanf("%19s%u", fach->fachname, &note);
    if (test == 2)
    {
        fach->u_benotet = benotet;
        fach->note = note;
    }
    else if (test == 1)
    {
        fach->u_benotet = unbenotet;
        scanf("%c", &fach->ub);
    }
    else
    {
        return 0;
    }

    char *pos;
    for (pos = fach->fachname; (pos = strchr(pos, '_')) != 0; pos++)
    {
        *pos = ' ';
    }

    fach->next = NULL;
    fach->prev = NULL;

    return test;
}

void schleife(fach_note *n, void (*func) (fach_note const *) )
{
    while (n != NULL)
    {
        func(n);
        n = n->next;
    }
}

fach_note *einfuegen(fach_note *head, fach_note *einfuegen)
{

    if (head == NULL)
    {
        return einfuegen;
    }
    head->prev = einfuegen;
    einfuegen->next = head;

    return einfuegen;
}

void ausgeben(fach_note const *note)
{
    printf("%-19s \t", note->fachname);

    if (note->u_benotet == benotet)
    {
        int vk = note->note / 10;
        int nk = note->note - (10 * vk);

        if ((vk < 4 && (nk == 0 || nk == 3 || nk == 7)) || ((vk == 4 || vk == 5) && nk == 0))
        {
            printf("%d,%d", vk, nk);
        }
        else
        {
            printf("Fehler: %d", note->note);
        }
    }
    else if (note->u_benotet == unbenotet)
    {
        char x = note->ub;

        if (x == 'B')
        {
            printf("bestanden");
        }
        else if (x == 'N')
        {
            printf("nicht bestanden");
        }
        else
        {
            printf("Fehler: %c", x);
        }
    }
    else
    {
        printf("Fehler: Unbekannte Art");
    }

    printf("\n");
}

fach_note *entfernen(fach_note *noten_kopf, fach_note **entf)
{
    *entf = noten_kopf;

    noten_kopf = noten_kopf->next;

    if (noten_kopf != NULL)
    {
        noten_kopf->prev = NULL;
    }

    return noten_kopf;
}
