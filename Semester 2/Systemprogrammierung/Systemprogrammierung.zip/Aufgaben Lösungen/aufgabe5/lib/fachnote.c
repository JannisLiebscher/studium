
#include <stdio.h>
#include <string.h>
#include "fachnote.h"

int einlesen(fach_note *fach)
{
    unsigned int note;
    int test;

    test = scanf("%19s%u", fach->fachname, &note);
    if (test == 2)
    {
        fach->u_benotet = benotet;
        fach->note = note;
    }
    else if (test == 1)
    {
        fach->u_benotet = unbenotet;
        scanf("%c", &fach->ub);
    }
    else
    {
        return 0;
    }

    char *pos;
    for (pos = fach->fachname; (pos = strchr(pos, '_')) != 0; pos++)
    {
        *pos = ' ';
    }

    fach->next = NULL;
    fach->prev = NULL;

    return test;
}

void ausgeben(fach_note const *note)
{
    printf("%-19s \t", note->fachname);

    if (note->u_benotet == benotet)
    {
        int vk = note->note / 10;
        int nk = note->note - (10 * vk);

        if ((vk < 4 && (nk == 0 || nk == 3 || nk == 7)) || ((vk == 4 || vk == 5) && nk == 0))
        {
            printf("%d,%d", vk, nk);
        }
        else
        {
            printf("Fehler: %d", note->note);
        }
    }
    else if (note->u_benotet == unbenotet)
    {
        char x = note->ub;

        if (x == 'B')
        {
            printf("bestanden");
        }
        else if (x == 'N')
        {
            printf("nicht bestanden");
        }
        else
        {
            printf("Fehler: %c", x);
        }
    }
    else
    {
        printf("Fehler: Unbekannte Art");
    }

    printf("\n");
}
