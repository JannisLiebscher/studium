#!/bin/sh 
for s in fachnote.c liste.c ; do 
    compile_command="gcc -c -I. -W -Wall -std=c11 -pedantic $s"
    echo $compile_command
    eval $compile_command
    if [ $? -ne 0 ] ; then    
        echo build failed     
        exit 1   
    fi 
done 
link_command="ar rs libaufgabe5.a fachnote.o liste.o" 
echo $link_commandeval 
$link_command
if [ $? -ne 0 ] ; then   
    echo build failed   
    exit 1 
fi 
echo build successful
