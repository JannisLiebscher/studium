#ifndef FACHNOTE_H
#define FACHNOTE_H

#define size 20

typedef struct fach_note fach_note;

enum benotet_oder_unbenotet {benotet, unbenotet};
struct fach_note
{
    fach_note *prev;
    fach_note *next;
    char fachname[size + 1];
    enum benotet_oder_unbenotet u_benotet ;
    union
    {
        int note;
        char ub;
    };
};

int einlesen(fach_note *fach);
void ausgeben(fach_note const *note);

#endif
