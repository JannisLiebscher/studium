#include <stddef.h>
#include <string.h>
#include "liste.h"


void schleife(fach_note *n, void (*func) (fach_note const *) )
{
    while (n != NULL)
    {
        func(n);
        n = n->next;
    }
}

fach_note *einfuegen(fach_note *head, fach_note *einfuegen)
{

    if (head == NULL)
    {
        return einfuegen;
    }
    head->prev = einfuegen;
    einfuegen->next = head;

    return einfuegen;
}
 
fach_note *entfernen(fach_note *noten_kopf, fach_note **entf)
{
    *entf = noten_kopf;

    noten_kopf = noten_kopf->next;

    if (noten_kopf != NULL)
    {
        noten_kopf->prev = NULL;
    }

    return noten_kopf;
}
