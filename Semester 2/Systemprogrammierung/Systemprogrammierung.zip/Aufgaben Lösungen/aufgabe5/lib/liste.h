#ifndef LISTE_H
#define LISTE_H

#include "fachnote.h"

void schleife(fach_note *n, void (*func) (fach_note const *) );
fach_note *einfuegen(fach_note *head, fach_note *einfuegen);
fach_note *entfernen(fach_note *noten_kopf, fach_note **entf);

#endif
