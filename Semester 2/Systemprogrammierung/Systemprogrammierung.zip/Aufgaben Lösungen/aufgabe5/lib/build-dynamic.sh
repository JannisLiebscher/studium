#!/bin/sh 
for s in fachnote.c liste.c ; do 
    compile_command="gcc -c -I. -W -Wall -std=c11 -pedantic -fpic $s"
    echo $compile_command
    eval $compile_command
    if [ $? -ne 0 ] ; then    
        echo build failed     
        exit 1   
    fi 
done 
link_command="gcc -shared -g fachnote.o liste.o -o libaufgabe5.so" 
echo $link_commandeval 
$link_command
if [ $? -ne 0 ] ; then   
    echo build failed   
    exit 1 
fi 
echo build successful
