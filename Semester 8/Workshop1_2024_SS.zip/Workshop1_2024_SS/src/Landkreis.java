record Landkreis(String name, int plz, int anzahlEinwohner) {}
