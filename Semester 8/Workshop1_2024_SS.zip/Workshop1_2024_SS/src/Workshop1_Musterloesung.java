// Workshop 1
// Programmiertechnik 2 - WS 2023/24

import java.io.IOException;

public class Workshop1_Musterloesung {
    public static void main(String[] args) throws IOException {
        System.out.println("Willkommen zum Workshop 1");
        System.out.println("66% (40 von 60 Punkte) der Teile müssen fehlerfrei laufen!");

        //Aufgabe1_WarmUp_Musterloesung.aufgabe();              // 12 Punkte
        //Aufgabe2_Datenanalyse_Musterloesung.aufgabe();        // 12 Punkte
        //Aufgabe3_Textanalyse_Musterloesung.aufgabe();         // 18 Punkte
        Aufgabe4_Movies_Musterloesung.aufgabe();              // 18 Punkte

    }
}



