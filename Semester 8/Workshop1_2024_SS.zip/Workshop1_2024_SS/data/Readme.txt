Herkunft von word_list_german_spell_checked.txt:

Alle mit Rechtschreibprüfung geprüften Wörter aus der deutschen Wikipedia:
https://www.aaabbb.de/WordList/WordList.php